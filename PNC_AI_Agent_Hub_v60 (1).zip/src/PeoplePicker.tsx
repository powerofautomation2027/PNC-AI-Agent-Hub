/* Typeahead people picker — Office 365 Users (SearchUserV2) with Dataverse
   systemusers fallback, merged with owners already found by the scan. */
import { useEffect, useRef, useState } from "react";
import type { Person } from "./connectors";

type Props = {
  value: string[]; onChange: (v: string[]) => void;
  search: (term: string) => Promise<Person[]>;
  /** instant local suggestions (shown on focus and on every keystroke) */
  local?: (term: string) => Person[];
  placeholder?: string; single?: boolean;
};

export default function PeoplePicker({ value, onChange, search, local, placeholder, single }: Props) {
  const [text, setText] = useState("");
  const [hits, setHits] = useState<Person[]>([]);
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [hi, setHi] = useState(0);
  const seq = useRef(0);

  const merge = (a: Person[], b: Person[]) => {
    const seen = new Set<string>(); const out: Person[] = [];
    [...a, ...b].forEach(p => { const k = p.email.toLowerCase(); if (p.email && !seen.has(k)) { seen.add(k); out.push(p); } });
    return out.slice(0, 12);
  };
  useEffect(() => {
    const t = text.trim();
    const my = ++seq.current;
    const loc = local ? local(t) : [];
    setHits(loc); setHi(0);
    if (!t) { setBusy(false); return; }
    setOpen(true);
    const h = setTimeout(async () => {
      setBusy(true);
      try { const r = await search(t); if (my === seq.current) { setHits(merge(loc, r)); setOpen(true); } }
      catch { /* keep local hits */ }
      finally { if (my === seq.current) setBusy(false); }
    }, 180);
    return () => clearTimeout(h);
  }, [text]);

  const add = (email: string) => {
    const e = email.trim(); if (!e) return;
    if (single) onChange([e]);
    else if (!value.some(v => v.toLowerCase() === e.toLowerCase())) onChange([...value, e]);
    setText(""); setHits([]); setOpen(false);
  };
  const key = (ev: React.KeyboardEvent<HTMLInputElement>) => {
    if (ev.key === "ArrowDown") { setHi(i => Math.min(hits.length - 1, i + 1)); ev.preventDefault(); }
    else if (ev.key === "ArrowUp") { setHi(i => Math.max(0, i - 1)); ev.preventDefault(); }
    else if (ev.key === "Enter" || ev.key === ";" || ev.key === ",") {
      ev.preventDefault();
      if (open && hits[hi]) add(hits[hi].email); else if (/@/.test(text)) add(text);
    } else if (ev.key === "Backspace" && !text && value.length && !single) onChange(value.slice(0, -1));
    else if (ev.key === "Escape") setOpen(false);
  };

  return (
    <div className="pp">
      <div className="ppbox">
        {value.map(v => <span key={v} className="ppchip">{v}<button onClick={() => onChange(value.filter(x => x !== v))}>×</button></span>)}
        <input value={text} placeholder={value.length ? (single ? "Type to change…" : "") : placeholder ?? "Type a name or email…"}
          onChange={e => setText(e.target.value)} onKeyDown={key} onFocus={() => { if (!text && local) setHits(local("")); setOpen(true); }}
          onBlur={() => setTimeout(() => { setOpen(false); if (/@/.test(text)) add(text); }, 180)} />
        {busy && <span className="ppspin">⏳</span>}
      </div>
      {open && (hits.length > 0 || (busy && text)) && (
        <div className="ppmenu">{busy && <div className="sub" style={{ padding: "6px 10px" }}>Searching directory…</div>}{hits.map((p, i) => (
          <div key={p.email + i} className={i === hi ? "ppitem on" : "ppitem"} onMouseDown={e => { e.preventDefault(); add(p.email); }}>
            <span className="ppav">{(p.name || p.email).split(/\s+/).map(w => w[0]).slice(0, 2).join("").toUpperCase()}</span>
            <div><div className="strong">{p.name || p.email}</div><div className="sub">{p.email}{p.title ? ` • ${p.title}` : ""}</div></div>
          </div>))}
        </div>
      )}
    </div>
  );
}
