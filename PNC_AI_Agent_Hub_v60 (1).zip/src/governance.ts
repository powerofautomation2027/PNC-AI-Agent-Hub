/* ------------------------------------------------------------------------
   Community-sourced governance features (Copilot Studio Kit "Agents to
   watch", Agent 365 "Agents at risk / without owners", Agent registry).
   Pure client-side from scan data.
------------------------------------------------------------------------ */
import type { Agent } from "./scanner";

export type Band = "High" | "Medium" | "Low";
export type Risk = { score: number; band: Band; reasons: string[] };

/** 🎯 Agents to Watch — 0–100 exposure score. */
export function riskOf(a: Agent): Risk {
  let s = 0; const r: string[] = [];
  const add = (n: number, why: string) => { s += n; r.push(`+${n} ${why}`); };
  const auth = a.authMode.toLowerCase();
  if (/^none$|no auth/.test(auth)) add(a.publishedOn ? 40 : 25, a.publishedOn ? "published with NO authentication" : "no authentication (draft)");
  else if ((!auth || /unspecified/.test(auth)) && a.kind !== "Agent Builder") add(15, "authentication unspecified");
  if (/any|multi|everyone/i.test(a.access ?? "")) add(10, `access policy: ${a.access}`);
  if (a.autonomous) add(20, "autonomous trigger (no human in loop)");
  const k = a.details?.knowledge ?? 0, t = a.details?.tools.length ?? 0;
  if (k >= 3) add(10, `${k} knowledge sources`);
  if (t > 0) add(Math.min(15, 5 + t * 2), `${t} tool/connector action(s)`);
  if (!a.owner) add(15, "no accountable owner");
  else if (a.ownerDisabled) add(15, "owner account disabled");
  if (a.isDefaultEnv) add(10, "lives in the Default environment");
  if (a.details && !a.details.instructions && a.kind !== "Classic (V1)" && a.kind !== "Agent Builder") add(5, "no instructions / guardrail prompt");
  const score = Math.min(100, s);
  return { score, band: score >= 60 ? "High" : score >= 30 ? "Medium" : "Low", reasons: r };
}

/** ♻ Lifecycle state machine. */
export type Life = "Active" | "Draft" | "Zombie draft" | "Stale" | "Orphaned" | "Dormant";
export const LIFE_ORDER: Life[] = ["Orphaned", "Dormant", "Zombie draft", "Stale", "Draft", "Active"];
export const LIFE_INFO: Record<Life, [string, string]> = {
  "Orphaned": ["🕳", "Owner missing or disabled — nobody accountable"],
  "Dormant": ["💤", "Inactive / deprovisioned / provisioning failed"],
  "Zombie draft": ["🧟", "Never published, created 90+ days ago"],
  "Stale": ["🕸", "Published but untouched for 180+ days"],
  "Draft": ["✏️", "Not published yet"],
  "Active": ["✅", "Published and maintained"]
};
const DAY = 864e5;
export function lifeOf(a: Agent, now = Date.now()): Life {
  if (!a.owner || a.ownerDisabled) return "Orphaned";
  if (/inactive|deprovision|fail|missing/i.test(`${a.state} ${a.status ?? ""}`)) return "Dormant";
  if (a.kind === "Flow") return /stop|suspend|off/i.test(a.state) ? "Dormant"
    : a.modifiedOn && now - +new Date(a.modifiedOn) > 180 * DAY ? "Stale" : "Active";
  if (a.kind === "Child Agent") return "Active";
  if (!a.publishedOn) return a.createdOn && now - +new Date(a.createdOn) > 90 * DAY ? "Zombie draft" : "Draft";
  if (a.modifiedOn && now - +new Date(a.modifiedOn) > 180 * DAY) return "Stale";
  return "Active";
}

/** Monthly growth: created vs published per month (last n months). */
export function growth(agents: Agent[], n = 12) {
  const now = new Date(); const out: { m: string; created: number; published: number }[] = [];
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    out.push({ m: d.toISOString().slice(0, 7), created: 0, published: 0 });
  }
  const idx = new Map(out.map((o, i) => [o.m, i]));
  agents.forEach(a => {
    const c = idx.get((a.createdOn || "").slice(0, 7)); if (c !== undefined) out[c].created++;
    const p = idx.get((a.publishedOn || "").slice(0, 7)); if (p !== undefined) out[p].published++;
  });
  return out;
}
