/* Original "PNC AI Agent Hub" mark — orbiting agent nodes around a glowing core,
   PNC orange + navy. Pure SVG + CSS animation, no external assets. */
export default function HubLogo({ size = 180 }: { size?: number }) {
  return (
    <svg className="hublogo" width={size} height={size} viewBox="0 0 200 200" role="img" aria-label="PNC AI Agent Hub">
      <defs>
        <radialGradient id="core" cx="50%" cy="45%" r="55%">
          <stop offset="0" stopColor="#FFC27A" /><stop offset=".55" stopColor="#F27A21" /><stop offset="1" stopColor="#B64F00" />
        </radialGradient>
        <linearGradient id="ring" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#F27A21" /><stop offset="1" stopColor="#3A7BD5" />
        </linearGradient>
        <filter id="glow" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="6" /></filter>
      </defs>
      <circle cx="100" cy="100" r="92" fill="#0B2B4C" />
      <circle cx="100" cy="100" r="86" fill="none" stroke="url(#ring)" strokeWidth="3" opacity=".9" />
      <g className="hubspin">
        <circle cx="100" cy="100" r="62" fill="none" stroke="#F27A21" strokeOpacity=".35" strokeWidth="1.5" strokeDasharray="4 7" />
        {[0, 72, 144, 216, 288].map((deg, i) => {
          const r = (deg * Math.PI) / 180, x = 100 + 62 * Math.cos(r), y = 100 + 62 * Math.sin(r);
          return (<g key={i}>
            <line x1="100" y1="100" x2={x} y2={y} stroke="#F27A21" strokeOpacity=".45" strokeWidth="1.4" />
            <circle cx={x} cy={y} r="9" fill="#0F3A63" stroke={i % 2 ? "#3A7BD5" : "#F27A21"} strokeWidth="2.5" />
            <circle cx={x} cy={y} r="3" fill="#fff" />
          </g>);
        })}
      </g>
      <circle cx="100" cy="100" r="30" fill="#F27A21" filter="url(#glow)" opacity=".6" />
      <circle cx="100" cy="100" r="26" fill="url(#core)" />
      <text x="100" y="108" textAnchor="middle" fontFamily="Segoe UI, Arial" fontWeight="800" fontSize="20" fill="#fff">AI</text>
    </svg>
  );
}
