import { useEffect, useMemo, useRef, useState } from "react";
import { getContext } from "@microsoft/power-apps/app";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { scanTenant, Agent, Kind, lookupById, extractId, LookupHit } from "./scanner";
import { atlas, sprawl, AtlasRow, Cluster, Tier } from "./community";
import { hasMail, sendMail, Attachment, hasQuarantine, getQuarantine, setQuarantine, hasInventory, listEnvironments, Env, hasPeople, searchPeople, searchPeopleDv, Person } from "./connectors";
import { riskOf, lifeOf, growth, LIFE_ORDER, LIFE_INFO, Life } from "./governance";
import PeoplePicker from "./PeoplePicker";
import CapabilityGraph from "./CapabilityGraph";
import { BUILD_STAMP } from "./buildInfo";
import { CSS } from "./styles";
import HubLogo from "./HubLogo";
import AgentMap from "./AgentMap";

type Tab = "all" | "copilot" | "builder" | "tree" | "map" | "classic" | "flows" | "owner" | "watch" | "lifecycle" | "atlas" | "sprawl" | "insights" | "security";
const TABS: [Tab, string][] = [
  ["all", "All"], ["copilot", "Copilot Studio"], ["builder", "Agent Builder"], ["tree", "🌳 Parent ↔ Child"], ["map", "🕸 Agent Map"],
  ["classic", "Classic (V1)"], ["flows", "Flows"], ["owner", "👤 Owner lookup"], ["watch", "🎯 Agents to Watch"], ["lifecycle", "♻ Lifecycle"],
  ["atlas", "🔌 Connector Atlas"], ["sprawl", "👯 Sprawl"], ["insights", "📊 Insights"], ["security", "🔒 Security"]
];
const KIND_OF: Partial<Record<Tab, Kind>> = { copilot: "Copilot Studio", builder: "Agent Builder", classic: "Classic (V1)", flows: "Flow" };
const PILL: Record<Kind, string> = { "Copilot Studio": "cs", "Agent Builder": "ab", "Child Agent": "sa", "Classic (V1)": "ot", "Flow": "m3" };

const day = (s: string) => (s ? s.slice(0, 10) : "");
const stamp = () => new Date().toISOString().slice(0, 10);
const studioLink = (a: Agent) => a.link;

/** When set, exports are captured as attachments (for 📧) instead of downloaded. */
let captureSink: Attachment[] | null = null;
function csvDownload(name: string, header: string[], rows: string[][]) {
  const esc = (v: string) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  const text = "﻿" + [header, ...rows].map(r => r.map(esc).join(",")).join("\r\n");
  if (captureSink) { captureSink.push({ name, b64: btoa(unescape(encodeURIComponent(text))) }); return text; }
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([text], { type: "text/csv;charset=utf-8" }));
  a.download = name; a.click(); URL.revokeObjectURL(a.href);
  return text;
}
function pdfDownload(title: string, sub: string, header: string[], rows: string[][], file: string) {
  // jsPDF core fonts are WinAnsi: map arrows/emoji to safe text
  const safe = (v: string) => String(v ?? "").replace(/↔/g, "<->").replace(/[▸→]/g, ">").replace(/✅/g, "").replace(/[^\x00-\xFF\u2013\u2014\u2018\u2019\u201C\u201D\u2022\u2026]/g, "").trim();
  title = safe(title); sub = safe(sub); header = header.map(safe); rows = rows.map(r => r.map(safe));
  const wide = header.length > 9;
  const doc = new jsPDF({ orientation: "landscape", unit: "pt", format: wide ? "a3" : "a4" });
  doc.setFontSize(17); doc.setTextColor(20, 33, 61); doc.text(title, 40, 42);
  doc.setFontSize(9); doc.setTextColor(90); doc.text(sub, 40, 58);
  autoTable(doc, {
    startY: 72, head: [header], body: rows,
    styles: { fontSize: wide ? 7 : 7.5, cellPadding: 3, overflow: "linebreak" },
    columnStyles: Object.fromEntries(header.map((h, i) => [i, /\bID\b/.test(h) ? { font: "courier", fontSize: 6.2, cellWidth: 148, textColor: [25, 35, 55] } : {}])), headStyles: { fillColor: [20, 33, 61], textColor: 255 },
    alternateRowStyles: { fillColor: [242, 245, 250] }
  });
  const pages = doc.getNumberOfPages();
  for (let i = 1; i <= pages; i++) {
    doc.setPage(i); doc.setFontSize(8); doc.setTextColor(140);
    doc.text("Created by Kirolos • Power of Automation", 40, doc.internal.pageSize.getHeight() - 18);
  }
  if (captureSink) { captureSink.push({ name: file, b64: doc.output("datauristring").split(",")[1] }); return; }
  doc.save(file);
}

export default function App() {
  const [user, setUser] = useState<{ name: string; upn: string }>({ name: "", upn: "" });
  const [agents, setAgents] = useState<Agent[]>([]);
  const [skipped, setSkipped] = useState<string[]>([]);
  const [notes, setNotes] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [prog, setProg] = useState({ msg: "", done: 0, total: 0 });
  const [error, setError] = useState("");
  const [tab, setTab] = useState<Tab>("all");
  const [q, setQ] = useState("");
  const [envF, setEnvF] = useState("all");
  const [sortKey, setSortKey] = useState<keyof Agent>("name");
  const [sortDir, setSortDir] = useState<1 | -1>(1);
  const [detail, setDetail] = useState<Agent | null>(null);
  const [quar, setQuar] = useState<Record<string, boolean | null>>({});
  const [qBusy, setQBusy] = useState("");
  const [deltaMsg, setDeltaMsg] = useState("");
  const [newIds, setNewIds] = useState<Set<string>>(new Set());
  const [showAbout, setShowAbout] = useState(false);
  const [theme, setTheme] = useState<"dark" | "light">(() => { try { return (localStorage.getItem("aih-theme") as any) || "dark"; } catch { return "dark"; } });
  const [mail, setMail] = useState<{ to: string[]; subject: string; csv: boolean; pdf: boolean; sending: boolean } | null>(null);
  const treeExport = useRef<((pdf: boolean) => void) | null>(null);
  const [autoScan, setAutoScan] = useState(false);
  const [allEnvs, setAllEnvs] = useState<Env[]>([]);
  const [envQ, setEnvQ] = useState("");
  const [envOpen, setEnvOpen] = useState(false);
  const [ownerSel, setOwnerSel] = useState<string[]>([]);
  const [lifeF, setLifeF] = useState<Life | "all">("all");
  const [idq, setIdq] = useState<{ q: string; busy: boolean; msg: string; local: Agent[]; live: LookupHit[]; searched: boolean } | null>(null);
  const [recert, setRecert] = useState<{ scope: "stale" | "risk" | "all"; days: number; sending: boolean; done: number; log: string[] } | null>(null);
  const [pins, setPins] = useState<Set<string>>(() => {
    try { return new Set(JSON.parse(localStorage.getItem("aih-pins") || "[]")); } catch { return new Set(); }
  });
  const cancel = useRef(false);

  useEffect(() => {
    try { localStorage.setItem("aih-theme", theme); } catch { }
    document.body.style.background = theme === "light" ? "#f4f6fa" : "#0e1726";
  }, [theme]);
  useEffect(() => {
    getContext().then(c => setUser({ name: c.user?.fullName ?? "", upn: c.user?.userPrincipalName ?? "" })).catch(() => {});
    // load environment names at start so environment search works before a scan
    listEnvironments().then(e => setAllEnvs(e.sort((a, b) => a.name.localeCompare(b.name)))).catch(() => {});
  }, []);

  async function run(scope?: string) {
    if (busy) return;
    cancel.current = false; setBusy(true); setError("");
    const sc = (scope ?? "").trim().toLowerCase();
    try {
      const r = await scanTenant((msg, done, total) => setProg({ msg, done, total }), () => cancel.current,
        sc ? (e => e.name.toLowerCase().includes(sc) || e.id.toLowerCase() === sc) : undefined);
      setAgents(r.agents); setSkipped(r.skipped); setNotes(r.notes);
      if (!sc) setAllEnvs([...r.envs].sort((a, b) => a.name.localeCompare(b.name)));
      // 🔄 delta vs previous scan
      try {
        const ids = r.agents.filter(a => a.relation !== "Connected").map(a => a.id.toLowerCase());
        const prev = JSON.parse(localStorage.getItem("aih-snapshot") || "null");
        if (prev) {
          const ps = new Set<string>(prev.ids);
          const added = ids.filter(i => !ps.has(i));
          const removed = prev.ids.filter((i: string) => !ids.includes(i)).length;
          setNewIds(new Set(added));
          setDeltaMsg(`🔄 Since last scan (${new Date(prev.when).toLocaleDateString()}): ${added.length} new, ${removed} removed`);
        }
        localStorage.setItem("aih-snapshot", JSON.stringify({ ids, when: new Date().toISOString() }));
      } catch { /* storage unavailable */ }
    } catch (e: any) {
      setError(String(e?.message ?? e));
    } finally { setBusy(false); }
  }
  useEffect(() => {
    if (!autoScan) return;
    const t = setInterval(() => run(), 15 * 60 * 1000);
    return () => clearInterval(t);
  }, [autoScan]);

  const real = agents.filter(a => a.relation !== "Connected");
  const count = (k: Kind) => real.filter(a => a.kind === k).length;
  const links = agents.filter(a => a.relation);
  const envList = useMemo(() => {
    const m = new Map<string, { id: string; name: string; n: number }>();
    real.forEach(a => { const e = m.get(a.envId) ?? { id: a.envId, name: a.envName, n: 0 }; e.n++; m.set(a.envId, e); });
    return [...m.values()].sort((a, b) => a.name.localeCompare(b.name));
  }, [agents]);

  /* ---------- people / owners ---------- */
  const knownOwners = useMemo(() => {
    const m = new Map<string, Person>();
    agents.forEach(a => { const k = (a.ownerEmail || a.owner).toLowerCase(); if (k && !m.has(k)) m.set(k, { name: a.owner, email: a.ownerEmail || a.owner }); });
    return [...m.values()];
  }, [agents]);
  const ownerCounts = useMemo(() => {
    const m = new Map<string, number>();
    agents.forEach(a => { const k = (a.ownerEmail || a.owner).toLowerCase(); if (k) m.set(k, (m.get(k) ?? 0) + 1); });
    return m;
  }, [agents]);
  /** instant local suggestions: owners found by the scan (no network) */
  function localPeople(term: string): Person[] {
    const t = term.trim().toLowerCase();
    return knownOwners
      .filter(p => !t || p.name.toLowerCase().includes(t) || p.email.toLowerCase().includes(t))
      .map(p => ({ ...p, title: `owns ${ownerCounts.get(p.email.toLowerCase()) ?? 0} item(s)` }))
      .sort((a, b) => (ownerCounts.get(b.email.toLowerCase()) ?? 0) - (ownerCounts.get(a.email.toLowerCase()) ?? 0))
      .slice(0, 8);
  }
  async function findPeople(term: string): Promise<Person[]> {
    const t = term.toLowerCase();
    const local = knownOwners.filter(p => p.name.toLowerCase().includes(t) || p.email.toLowerCase().includes(t)).slice(0, 5)
      .map(p => ({ ...p, title: "agent owner" }));
    let remote: Person[] = [];
    try {
      if (hasPeople()) remote = await searchPeople(term);
      else {
        const env = allEnvs.find(e => e.isDefault && e.url) ?? allEnvs.find(e => e.url);
        if (env?.url) remote = await searchPeopleDv(env.url, term);
      }
    } catch { /* fall back to local owners only */ }
    const seen = new Set<string>(); const out: Person[] = [];
    [...local, ...remote].forEach(p => { const k = p.email.toLowerCase(); if (!seen.has(k)) { seen.add(k); out.push(p); } });
    return out.slice(0, 10);
  }
  const ownerKey = (ownerSel[0] ?? "").toLowerCase();
  const envMatches = useMemo(() => {
    const t = envQ.trim().toLowerCase();
    const src = allEnvs.length ? allEnvs : envList.map(e => ({ id: e.id, name: e.name, region: "", sku: "", url: "", isDefault: false } as Env));
    return t ? src.filter(e => e.name.toLowerCase().includes(t) || e.id.toLowerCase().includes(t)) : src;
  }, [envQ, allEnvs, agents]);
  const envCount = (id: string) => envList.find(e => e.id === id)?.n;

  const view = useMemo(() => {
    const ql = q.trim().toLowerCase();
    const eq = envQ.trim().toLowerCase();
    let base = tab === "tree" ? links : KIND_OF[tab] ? real.filter(a => a.kind === KIND_OF[tab]) :
      tab === "owner" ? (ownerKey ? agents.filter(a => (a.ownerEmail || "").toLowerCase() === ownerKey || a.owner.toLowerCase() === ownerKey) : []) : real;
    return base
      .filter(a => envF === "all" || a.envId === envF)
      .filter(a => envF !== "all" || !eq || a.envName.toLowerCase().includes(eq))
      .filter(a => !ql || [a.name, a.owner, a.ownerEmail, a.envName, a.schema, a.parentName, a.kind, a.id, a.parentId].some(v => (v ?? "").toLowerCase().includes(ql)))
      .sort((a, b) => {
        const p = (pins.has(b.id) ? 1 : 0) - (pins.has(a.id) ? 1 : 0);
        if (p) return p;
        const av = String(a[sortKey] ?? "").toLowerCase(), bv = String(b[sortKey] ?? "").toLowerCase();
        return av < bv ? -sortDir : av > bv ? sortDir : 0;
      });
  }, [agents, tab, q, envF, envQ, ownerKey, sortKey, sortDir, pins]);

  const sortBy = (k: keyof Agent) => { if (sortKey === k) setSortDir(d => (d === 1 ? -1 : 1)); else { setSortKey(k); setSortDir(1); } };
  const arrow = (k: keyof Agent) => (sortKey === k ? (sortDir === 1 ? " ▲" : " ▼") : "");
  const togglePin = (id: string) => setPins(p => {
    const n = new Set(p); n.has(id) ? n.delete(id) : n.add(id);
    try { localStorage.setItem("aih-pins", JSON.stringify([...n])); } catch { }
    return n;
  });

  /* ---------- security findings (OWASP LLM Top-10 / Agentic aligned) ---------- */
  const findings = useMemo(() => {
    const now = Date.now();
    return real.filter(a => a.kind !== "Flow" && a.kind !== "Child Agent").map(a => {
      const f: [string, string][] = [];
      if (a.autonomous) f.push(["OWASP LLM06 Excessive Agency", "⚡ Autonomous trigger — runs without a user in the loop"]);
      if (/^none$|no authentication/i.test(a.authMode)) f.push(["Access control", "🔓 No end-user authentication"]);
      if (!a.owner) f.push(["Governance", "🕳 No accountable owner"]);
      if (a.kind === "Classic (V1)") f.push(["Lifecycle", "🗿 Legacy Classic (V1) — migrate"]);
      if ((a.details?.tools.length ?? 0) >= 5) f.push(["OWASP LLM06", `🧰 ${a.details!.tools.length} tools/connectors — wide action surface`]);
      if (a.publishedOn && a.modifiedOn && now - new Date(a.modifiedOn).getTime() > 180 * 864e5) f.push(["OWASP LLM09", "💤 Published, unreviewed 180+ days"]);
      if (a.details && !a.details.instructions && a.kind !== "Classic (V1)") f.push(["OWASP LLM01", "📝 No instructions — no guardrail prompt"]);
      return { a, f };
    }).filter(x => x.f.length).sort((x, y) => y.f.length - x.f.length);
  }, [agents]);

  /* ---------- 🎯 risk + ♻ lifecycle ---------- */
  const scored = useMemo(() => real.filter(a => a.kind !== "Flow" && a.kind !== "Child Agent")
    .map(a => ({ a, r: riskOf(a) })).sort((x, y) => y.r.score - x.r.score), [agents]);
  const riskById = useMemo(() => new Map(scored.map(x => [x.a.id, x.r])), [scored]);
  const lives = useMemo(() => real.map(a => ({ a, l: lifeOf(a) })), [agents]);
  const envScope = (a: Agent) => (envF === "all" || a.envId === envF) && (envF !== "all" || !envQ.trim() || a.envName.toLowerCase().includes(envQ.trim().toLowerCase()));

  /* ---------- 🔌 atlas + 👯 sprawl ---------- */
  const atlasRows = useMemo(() => atlas(real.filter(a => a.kind !== "Flow")), [agents]);
  const sprawlCl = useMemo(() => sprawl(real), [agents]);
  const ATLAS_H = ["Risk tier", "Connector / endpoint", "Type", "DLP unblockable", "Agents", "Environments", "Operations", "Agents [IDs]"];
  const atlasExport = () => atlasRows.map(r => [r.tier, r.name, r.kind, r.unblockable ? "yes" : "no", String(r.agents.filter(envScope).length), r.envs.join("; "), r.ops.join("; "), r.agents.filter(envScope).map(a => `${a.name} [${cleanId(a)}]`).join("; ")])
    .filter(r => r[4] !== "0");
  const SPRAWL_H = ["Cluster", "Verdict", "Similarity", "Agent", "Agent ID", "Type", "Environment", "Owner Name", "Owner Email", "Why", "Open Link"];
  const sprawlExport = () => sprawlCl.flatMap((c, i) => c.members.map(m => [String(i + 1), c.label, `${Math.round(c.top * 100)}%`, m.name, cleanId(m), m.kind, m.envName, m.owner || "-", m.ownerEmail || "-",
    [...new Set(c.pairs.filter(p => p.a === m || p.b === m).flatMap(p => p.why))].join("; "), m.link]));

  /* ---------- per-tab exports ---------- */
  /* Export columns (Power CAT Copilot Studio Kit / CoE / PPAC inventory aligned).
     [header, value, includeInPdf] */
  type Col = [string, (a: Agent) => string, boolean];
  const cleanId = (a: Agent) => a.id.split("|")[0];
  const kidIds = (a: Agent, rel: "Child" | "Connected") => a.relation ? "" :
    agents.filter(x => x.relation === rel && (x.parentId ?? "").toLowerCase() === a.id.toLowerCase()).map(x => `${x.name} [${cleanId(x)}]`).join("; ");
  const capText = (a: Agent) => [...(a.details?.caps ?? []).map(c => `${c.kind}: ${c.name}${c.ops.length ? ` (${c.ops.join("/")})` : ""}`), ...(a.details?.skills ?? []).map(s => `Skill: ${s}`)].join("; ");
  const hasCap = (a: Agent, re: RegExp) => a.details?.caps ? ((a.details.caps.some(c => re.test(c.kind))) ? "Yes" : "No") : "";
  const sinceDays = (d: string) => (d ? String(Math.max(0, Math.floor((Date.now() - new Date(d).getTime()) / 864e5))) : "");
  const yn = (b: boolean | undefined) => (b === undefined ? "" : b ? "Yes" : "No");
  const COLS: Col[] = [
    ["Agent", a => a.name, true],
    ["Agent Role", a => roleOf(a)[1], true],
    ["Type", a => a.kind, false],
    ["Agent ID", cleanId, true],
    ["Parent Agent", a => a.parentName, true],
    ["Parent Agent ID", a => a.parentId, true],
    ["Relationship", a => a.relation, false],
    ["Child Agents [IDs]", a => kidIds(a, "Child"), false],
    ["Connected Agents [IDs]", a => kidIds(a, "Connected"), false],
    ["Environment", a => a.envName, true],
    ["Environment ID", a => a.envId, false],
    ["Default Environment", a => yn(a.isDefaultEnv), false],
    ["Owner Name", a => a.owner, true],
    ["Owner Email", a => a.ownerEmail, true],
    ["Owner Disabled / Orphaned", a => (!a.owner ? "Orphaned (no owner)" : yn(a.ownerDisabled)), false],
    ["State", a => a.state, false],
    ["Status Reason", a => a.status ?? "", false],
    ["Lifecycle", a => lifeOf(a), true],
    ["Exposure Score", a => String(riskById.get(a.id)?.score ?? ""), true],
    ["Risk Band", a => riskById.get(a.id)?.band ?? "", false],
    ["Risk Reasons", a => (riskById.get(a.id)?.reasons ?? []).join("; "), false],
    ["Quarantined", a => yn(quar[a.id] ?? a.quarantined ?? undefined), false],
    ["End-User Auth", a => a.authMode, false],
    ["Access Policy", a => a.access ?? "", false],
    ["Orchestration", a => a.orchestration ?? "", false],
    ["Autonomous Triggers", a => (a.details ? String(a.details.triggers) : ""), false],
    ["Knowledge Sources", a => (a.details ? `${a.details.knowledge}${a.details.knowledgeNames?.length ? `: ${a.details.knowledgeNames.join("; ")}` : ""}` : ""), false],
    ["Tools / Connectors / Skills", capText, false],
    ["Uses MCP", a => hasCap(a, /MCP/), false],
    ["Uses HTTP", a => hasCap(a, /HTTP/), false],
    ["Uses Computer Use", a => hasCap(a, /Computer/), false],
    ["Instructions Present", a => (a.details ? yn(!!a.details.instructions) : ""), false],
    ["Entra Agent ID", a => a.entraAgentId ?? "", false],
    ["Template", a => a.template, false],
    ["Detected Via", a => a.source ?? "", false],
    ["Created", a => day(a.createdOn), false],
    ["Modified", a => day(a.modifiedOn), true],
    ["Days Since Modified", a => sinceDays(a.modifiedOn), false],
    ["Published", a => day(a.publishedOn), false],
    ["Schema", a => a.schema, false],
    ["Open Link", a => a.link, false]
  ];
  const PDF_IDX = COLS.map((c, i) => (c[2] ? i : -1)).filter(i => i >= 0);
  const tableRows = () => view.map(a => COLS.map(c => c[1](a) ?? ""));
  function exportCsv() {
    if (tab === "tree") return treeExport.current?.(false);
    if (tab === "security") return csvDownload(`agent-security-${stamp()}.csv`, ["Agent", "Agent ID", "Agent Role", "Environment", "Owner Name", "Owner Email", "Category", "Finding", "Open Link"],
      findings.flatMap(x => x.f.map(([c, l]) => [x.a.name, cleanId(x.a), roleOf(x.a)[1], x.a.envName, x.a.owner, x.a.ownerEmail, c, l, x.a.link])));
    if (tab === "insights") return csvDownload(`agent-insights-${stamp()}.csv`, ["Metric", "Value"], insightRows());
    if (tab === "watch") return csvDownload(`agents-to-watch-${stamp()}.csv`, WATCH_H, watchRows());
    if (tab === "lifecycle") return csvDownload(`agent-lifecycle-${stamp()}.csv`, LIFE_H, lifeRows());
    if (tab === "atlas") return csvDownload(`connector-atlas-${stamp()}.csv`, ATLAS_H, atlasExport());
    if (tab === "sprawl") return csvDownload(`agent-sprawl-${stamp()}.csv`, SPRAWL_H, sprawlExport());
    if (tab === "owner") return csvDownload(`agents-owned-by-${(ownerSel[0] || "nobody").replace(/[^\w.@-]/g, "_")}-${stamp()}.csv`, COLS.map(c => c[0]), tableRows());
    return csvDownload(`agent-inventory-${tab}-${stamp()}.csv`, COLS.map(c => c[0]), tableRows());
  }
  function exportPdf() {
    if (tab === "tree") return treeExport.current?.(true);
    const sub = `Generated ${new Date().toLocaleString()} by ${user.name || user.upn} • ${tab}`;
    if (tab === "security") return pdfDownload("Agent Security Review", sub, ["Agent", "Agent ID", "Environment", "Owner Name", "Owner Email", "Category", "Finding"],
      findings.flatMap(x => x.f.map(([c, l]) => [x.a.name, cleanId(x.a), x.a.envName, x.a.owner || "-", x.a.ownerEmail || "-", c, l])), `agent-security-${stamp()}.pdf`);
    if (tab === "insights") return pdfDownload("Agent Governance Insights", sub, ["Metric", "Value"], insightRows(), `agent-insights-${stamp()}.pdf`);
    if (tab === "watch") return pdfDownload("Agents to Watch — Exposure Score", sub, WATCH_H.slice(0, 9), watchRows().map(r => r.slice(0, 9)), `agents-to-watch-${stamp()}.pdf`);
    if (tab === "atlas") return pdfDownload("Connector Atlas — DLP risk view", sub, ATLAS_H.slice(0, 7), atlasExport().map(r => r.slice(0, 7)), `connector-atlas-${stamp()}.pdf`);
    if (tab === "sprawl") return pdfDownload("Agent Sprawl — duplicate & sibling agents", sub, SPRAWL_H.slice(0, 10), sprawlExport().map(r => r.slice(0, 10)), `agent-sprawl-${stamp()}.pdf`);
    if (tab === "lifecycle") return pdfDownload("Agent Lifecycle Report", sub, LIFE_H.slice(0, 11), lifeRows().map(r => r.slice(0, 11)), `agent-lifecycle-${stamp()}.pdf`);
    if (tab === "owner") {
      return pdfDownload(`Agents owned by ${ownerSel[0] || "—"}`, sub, PDF_IDX.map(i => COLS[i][0]), tableRows().map(r => PDF_IDX.map(i => r[i])), `agents-owned-${stamp()}.pdf`);
    }
    pdfDownload("Agent Inventory Report", sub, PDF_IDX.map(i => COLS[i][0]), tableRows().map(r => PDF_IDX.map(i => r[i])), `agent-inventory-${tab}-${stamp()}.pdf`);
  }
  const WATCH_H = ["Score", "Band", "Agent", "Agent ID", "Type", "Environment", "Owner Name", "Owner Email", "Why", "Open Link"];
  const watchRows = () => scored.filter(x => envScope(x.a)).map(({ a, r }) =>
    [String(r.score), r.band, a.name, cleanId(a), a.kind, a.envName, a.owner || "-", a.ownerEmail || "-", r.reasons.join("; "), a.link]);
  const LIFE_H = ["Lifecycle", "Agent", "Agent ID", "Parent Agent ID", "Type", "Environment", "Owner Name", "Owner Email", "Created", "Modified", "Published", "Open Link"];
  const lifeRows = () => lives.filter(x => envScope(x.a) && (lifeF === "all" || x.l === lifeF))
    .sort((x, y) => LIFE_ORDER.indexOf(x.l) - LIFE_ORDER.indexOf(y.l) || x.a.name.localeCompare(y.a.name))
    .map(({ a, l }) => [l, a.name, cleanId(a), a.parentId, a.kind, a.envName, a.owner || "-", a.ownerEmail || "-", day(a.createdOn), day(a.modifiedOn), day(a.publishedOn) || "never", a.link]);
  function insightRows(): string[][] {
    return [["Total agents", String(real.filter(a => a.kind !== "Flow").length)], ["Copilot Studio", String(count("Copilot Studio"))],
      ["Agent Builder", String(count("Agent Builder"))], ["Child agents", String(count("Child Agent"))],
      ["Connected-agent links", String(agents.filter(a => a.relation === "Connected").length)], ["Classic (V1)", String(count("Classic (V1)"))],
      ["Flows", String(count("Flow"))], ["Autonomous", String(real.filter(a => a.autonomous).length)],
      ["Agents with security findings", String(findings.length)], ["🎯 High-exposure agents (score ≥ 60)", String(scored.filter(x => x.r.band === "High").length)],
      ["🕳 Orphaned (owner missing/disabled)", String(lives.filter(x => x.l === "Orphaned").length)],
      ["🧟 Zombie drafts / 🕸 Stale", `${lives.filter(x => x.l === "Zombie draft").length} / ${lives.filter(x => x.l === "Stale").length}`],
      ["🔌 Connectors in use / high-risk", `${atlasRows.length} / ${atlasRows.filter(r => r.tier === "High" || r.tier === "Custom").length}`],
      ["👯 Duplicate (twin) agent clusters", String(sprawlCl.filter(c => c.label === "Twin").length)],
      ["Environments with agents", String(envList.length)]];
  }

  const REPORT_NAME: Record<Tab, string> = {
    all: "Agent Inventory", copilot: "Copilot Studio Agents", builder: "Agent Builder Agents", tree: "Parent ↔ Child Agents",
    classic: "Classic (V1) Bots", map: "Agent Inventory", flows: "Flows", insights: "Governance Insights", security: "Security Review",
    owner: "Agents by Owner", watch: "Agents to Watch", lifecycle: "Agent Lifecycle", atlas: "Connector Atlas", sprawl: "Agent Sprawl"
  };
  function openMail() {
    setMail({ to: user.upn ? [user.upn] : [], subject: `${REPORT_NAME[tab]} report — ${new Date().toLocaleDateString()}`, csv: true, pdf: true, sending: false });
  }
  /** 📧 Email ANY report: re-runs the current tab's CSV/PDF export into attachments. */
  async function sendReport() {
    if (!mail) return;
    if (!hasMail()) { alert("Email needs the Office 365 Outlook connection. Create it at make.powerapps.com → Connections, then rerun deploy.ps1."); return; }
    setMail({ ...mail, sending: true });
    const files: Attachment[] = [];
    captureSink = files;
    try { if (mail.csv) exportCsv(); if (mail.pdf) exportPdf(); } finally { captureSink = null; }
    const summary = insightRows().map(r => `<tr><td style="padding:6px 12px;border:1px solid #d6dde9">${r[0]}</td><td style="padding:6px 12px;border:1px solid #d6dde9"><b>${r[1]}</b></td></tr>`).join("");
    const html = `<div style="font-family:Segoe UI,Arial">
      <div style="border-top:4px solid #F27A21;padding-top:10px"><h2 style="margin:0;color:#0B2B4C">${REPORT_NAME[tab]} report</h2>
      <p style="color:#5a6a84">Generated ${new Date().toLocaleString()} by ${user.name || user.upn} • ${files.length} attachment(s)</p></div>
      <table style="border-collapse:collapse">${summary}</table>
      <p style="color:#8a97ab;font-size:12px;margin-top:18px">Created by Kirolos • Power of Automation — PNC AI Agent Hub</p></div>`;
    try {
      await sendMail(mail.to.join(";"), mail.subject, html, files);
      setMail(null); alert(`📧 ${REPORT_NAME[tab]} report sent to ${mail.to.join(", ")}`);
    } catch (e: any) { setMail(m => (m ? { ...m, sending: false } : m)); alert("Send failed: " + (e?.message ?? e)); }
  }
  function schedule() {
    const n = new Date(); n.setDate(n.getDate() + ((8 - n.getDay()) % 7 || 7)); n.setHours(9, 0, 0, 0);
    const dt = n.toISOString().replace(/[-:]/g, "").slice(0, 15) + "Z";
    const ics = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//AgentInventoryHub//EN", "BEGIN:VEVENT", `UID:aih-${Date.now()}`,
      `DTSTART:${dt}`, "DURATION:PT15M", "RRULE:FREQ=WEEKLY", "SUMMARY:📊 Agent Inventory scan + email report",
      "BEGIN:VALARM", "TRIGGER:-PT10M", "ACTION:DISPLAY", "DESCRIPTION:Agent scan", "END:VALARM", "END:VEVENT", "END:VCALENDAR"].join("\r\n");
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([ics], { type: "text/calendar" }));
    a.download = "weekly-agent-report.ics"; a.click();
  }

  /* ---------- 📨 owner recertification campaign ---------- */
  type RItem = { a: Agent; l: Life; score: number };
  const recertItems = (scope: "stale" | "risk" | "all"): RItem[] => lives
    .filter(x => x.a.kind !== "Flow" && x.a.relation !== "Connected" && envScope(x.a))
    .map(x => ({ a: x.a, l: x.l, score: riskById.get(x.a.id)?.score ?? 0 }))
    .filter(x => scope === "all" || (scope === "stale" ? ["Stale", "Zombie draft", "Dormant", "Draft"].includes(x.l) : x.score >= 60));
  const groupByOwner = (items: RItem[]) => {
    const m = new Map<string, { name: string; email: string; items: RItem[] }>();
    items.filter(x => /@/.test(x.a.ownerEmail) && !x.a.ownerDisabled).forEach(x => {
      const k = x.a.ownerEmail.toLowerCase();
      if (!m.has(k)) m.set(k, { name: x.a.owner, email: x.a.ownerEmail, items: [] });
      m.get(k)!.items.push(x);
    });
    return [...m.values()].sort((a, b) => b.items.length - a.items.length);
  };
  const recertHtml = (o: { name: string; items: RItem[] }, due: string) => `<div style="font-family:Segoe UI,Arial;color:#1d2b44">
    <div style="border-top:4px solid #F27A21;padding-top:10px"><h2 style="margin:0;color:#0B2B4C">Action needed: confirm your AI agents</h2>
    <p>Hi ${o.name || "there"},</p>
    <p>As part of AI agent governance, please review the <b>${o.items.length}</b> agent(s) you own below and reply to this email by <b>${due}</b>
    with <b>KEEP</b> or <b>RETIRE</b> next to each name. Agents without a response may be quarantined.</p></div>
    <table style="border-collapse:collapse;font-size:13px">
      <tr style="background:#0B2B4C;color:#fff">${["Agent", "Type", "Environment", "Lifecycle", "Exposure", "Last modified", "Your decision"].map(h => `<th style="padding:6px 10px;text-align:left">${h}</th>`).join("")}</tr>
      ${o.items.map((x, i) => `<tr style="background:${i % 2 ? "#f2f5fa" : "#fff"}">
        <td style="padding:6px 10px;border:1px solid #d6dde9"><a href="${x.a.link}">${x.a.name}</a></td>
        <td style="padding:6px 10px;border:1px solid #d6dde9">${x.a.kind}</td><td style="padding:6px 10px;border:1px solid #d6dde9">${x.a.envName}</td>
        <td style="padding:6px 10px;border:1px solid #d6dde9">${LIFE_INFO[x.l][0]} ${x.l}</td>
        <td style="padding:6px 10px;border:1px solid #d6dde9">${x.score >= 60 ? "🔴" : x.score >= 30 ? "🟠" : "🟢"} ${x.score}</td>
        <td style="padding:6px 10px;border:1px solid #d6dde9">${day(x.a.modifiedOn) || "—"}</td>
        <td style="padding:6px 10px;border:1px solid #d6dde9">KEEP / RETIRE</td></tr>`).join("")}
    </table>
    <p style="color:#8a97ab;font-size:12px;margin-top:18px">Sent by ${user.name || user.upn} via PNC AI Agent Hub • Created by Kirolos • Power of Automation</p></div>`;
  async function runRecert(test: boolean) {
    if (!recert) return;
    if (!hasMail()) { alert("Needs the Office 365 Outlook connection."); return; }
    const owners = groupByOwner(recertItems(recert.scope));
    if (!owners.length) return;
    const due = new Date(Date.now() + recert.days * 864e5).toLocaleDateString();
    const targets = test ? owners.slice(0, 1) : owners;
    if (!test && !confirm(`Send recertification emails to ${owners.length} owner(s) covering ${owners.reduce((n, o) => n + o.items.length, 0)} agent(s)?`)) return;
    setRecert(r => r && { ...r, sending: true, done: 0, log: [] });
    const log: string[] = [];
    for (const o of targets) {
      const to = test ? user.upn : o.email;
      try {
        await sendMail(to, `${test ? `[TEST for ${o.email}] ` : ""}Action needed: confirm your ${o.items.length} AI agent(s) by ${due}`, recertHtml(o, due), []);
        log.push(`✅ ${to}${test ? ` (preview of ${o.email})` : ""} — ${o.items.length} agent(s)`);
      } catch (e: any) { log.push(`❌ ${o.email} — ${e?.message ?? e}`); }
      setRecert(r => r && { ...r, done: log.length, log: [...log] });
    }
    if (!test) {
      try {
        const hist = JSON.parse(localStorage.getItem("aih-recert") || "[]");
        hist.unshift({ when: new Date().toISOString(), scope: recert.scope, due, owners: owners.length, agents: owners.reduce((n, o) => n + o.items.length, 0) });
        localStorage.setItem("aih-recert", JSON.stringify(hist.slice(0, 20)));
      } catch { }
      // attestation tracker to record replies
      csvDownload(`recertification-tracker-${stamp()}.csv`, ["Owner Name", "Owner Email", "Agent", "Agent ID", "Type", "Environment", "Lifecycle", "Exposure", "Sent", "Due", "Decision (KEEP/RETIRE)", "Open Link"],
        owners.flatMap(o => o.items.map(x => [o.name, o.email, x.a.name, x.a.id.split("|")[0], x.a.kind, x.a.envName, x.l, String(x.score), stamp(), due, "", x.a.link])));
    }
    setRecert(r => r && { ...r, sending: false });
  }

  /* ---------- 🆔 identify any agent id ---------- */
  function roleOf(a: Agent): [string, string, string] {
    const callers = agents.filter(x => x.relation === "Connected" && x.id.toLowerCase().startsWith(a.id.toLowerCase() + "|")).map(x => x.parentName);
    if (a.kind === "Flow") return ["⚙️", "Power Automate flow", "Cloud flow (can be an agent tool)"];
    if (a.relation === "Child") return ["🧒", "Child agent", `Lives INSIDE parent agent “${a.parentName}” — not a separate bot`];
    if (a.relation === "Connected") return ["🔗", "Connected agent", `Separate agent called by “${a.parentName}”`];
    if (a.kind === "Agent Builder") return ["🪶", "Copilot (lite) agent — Agent Builder", "Built in Microsoft 365 Copilot Agent Builder; managed in M365 admin center"];
    if (a.kind === "Classic (V1)") return ["🗿", "Classic (V1) bot", "Legacy Power Virtual Agents bot — candidate for migration"];
    const ch = a.details?.children.length ?? 0, co = a.details?.connected.length ?? 0;
    if (ch || co) return ["👑", "Parent agent — Copilot Studio (full)", `Orchestrates ${ch} child and ${co} connected agent(s)${callers.length ? ` • also called by ${callers.join(", ")}` : ""}`];
    return ["🤖", "Copilot Studio (full) agent", callers.length ? `Standalone agent, also used as a connected agent by ${callers.join(", ")}` : "Standalone Copilot Studio agent"];
  }
  function findLocal(raw: string): Agent[] {
    const id = extractId(raw).toLowerCase(); if (!id) return [];
    const exact = agents.filter(a => a.id.toLowerCase() === id || a.schema.toLowerCase() === id);
    const viaConn = agents.filter(a => a.relation === "Connected" && a.id.toLowerCase().startsWith(id + "|"));
    const byName = exact.length || viaConn.length ? [] : agents.filter(a => !a.relation && a.name.toLowerCase() === id);
    const out: Agent[] = [];
    [...exact, ...byName].forEach(a => !out.includes(a) && out.push(a));
    if (!out.length && viaConn.length) out.push(viaConn[0]);
    return out;
  }
  async function runIdLookup(live: boolean) {
    if (!idq?.q.trim()) return;
    const local = findLocal(idq.q);
    setIdq(s => s && { ...s, local, live: [], searched: true, msg: "" });
    if (!live && local.length) return;
    if (!allEnvs.some(e => e.url)) { setIdq(s => s && { ...s, msg: "Environments not loaded yet." }); return; }
    setIdq(s => s && { ...s, busy: true, msg: "Searching every environment live…" });
    try {
      const hits = await lookupById(allEnvs, idq.q, m => setIdq(s => s && { ...s, msg: m }));
      setIdq(s => s && { ...s, busy: false, live: hits, msg: hits.length ? "" : "Not found in any Dataverse environment you can read." });
    } catch (e: any) { setIdq(s => s && { ...s, busy: false, msg: String(e?.message ?? e) }); }
  }

  /* ---------- NEW: quarantine ---------- */
  async function openDetail(a: Agent) {
    setDetail(a);
    if (hasQuarantine() && a.kind !== "Flow" && !a.relation && quar[a.id] === undefined) {
      try { const s = await getQuarantine(a.envId, a.id); setQuar(m => ({ ...m, [a.id]: s })); }
      catch { setQuar(m => ({ ...m, [a.id]: null })); }
    }
  }
  async function toggleQuarantine(a: Agent) {
    const on = !quar[a.id];
    if (!confirm(on ? `Quarantine "${a.name}"? It stops responding to users on every channel until released.` : `Release "${a.name}" from quarantine?`)) return;
    setQBusy(a.id);
    try { await setQuarantine(a.envId, a.id, on); setQuar(m => ({ ...m, [a.id]: on })); }
    catch (e: any) { alert("Quarantine change failed: " + (e?.message ?? e)); }
    finally { setQBusy(""); }
  }

  const pct = prog.total ? Math.round((prog.done / prog.total) * 100) : 0;

  /* ================================ render ================================ */
  return (
    <div className="shell" data-theme={theme}>
      <style dangerouslySetInnerHTML={{ __html: CSS }} />
      <header className="top">
        <div className="brand">
          <HubLogo size={52} />
          <div>
            <div className="eyebrow">POWER PLATFORM • TENANT-WIDE • NO APP REGISTRATION</div>
            <h1>PNC AI Agent Hub</h1>
            <div className="buildtag mono">build {BUILD_STAMP} • connector mode <button className="aboutbtn" onClick={() => setShowAbout(true)}>ⓘ About</button></div>
          </div>
          <img className="pnclogo" src="./pnc_logo.png" alt="PNC" onError={e => (e.currentTarget.style.display = "none")} />
          <img className="brandlogo" src="./logo_left.png" alt="" onError={e => (e.currentTarget.style.display = "none")} />
          <img className="brandlogo" src="./logo_right.png" alt="" onError={e => (e.currentTarget.style.display = "none")} />
        </div>
        <div className="headright">
        <button className="themebtn" onClick={() => setTheme(t => (t === "dark" ? "light" : "dark"))}>{theme === "dark" ? "☀️ Light mode" : "🌙 Dark mode"}</button>
        <div className="who"><span className="dot on" /><div>
          <div className="who-name">{user.name || "Signed in"}</div><div className="who-upn">{user.upn} • via Power Apps connections</div>
        </div></div></div>
      </header>

      <section className="actions">
        <button className="scan all" disabled={busy} onClick={() => run()}>🔎 Scan tenant — every agent type</button>
        <button className="dl idbtn" onClick={() => setIdq({ q: "", busy: false, msg: "", local: [], live: [], searched: false })} title="Paste any agent / child agent / flow id, schema name or URL">🆔 Find by ID</button>
        <div className="envfind">
          <input className="search" placeholder={`🌐 Find environment by name${allEnvs.length ? ` (${allEnvs.length})` : ""}…`} value={envQ}
            onChange={e => { setEnvQ(e.target.value); setEnvOpen(true); if (!e.target.value) setEnvF("all"); }}
            onFocus={() => setEnvOpen(true)} onBlur={() => setTimeout(() => setEnvOpen(false), 180)} />
          {envQ && <button className="envx" onClick={() => { setEnvQ(""); setEnvF("all"); }}>×</button>}
          {envOpen && envMatches.length > 0 && (
            <div className="ppmenu">{envMatches.slice(0, 40).map(e => (
              <div key={e.id} className={envF === e.id ? "ppitem on" : "ppitem"} onMouseDown={ev => { ev.preventDefault(); setEnvQ(e.name); setEnvF(envCount(e.id) !== undefined ? e.id : "all"); setEnvOpen(false); }}>
                <span className="ppav">{e.isDefault ? "★" : "🌐"}</span>
                <div><div className="strong">{e.name}</div><div className="sub mono">{e.region}{e.sku ? ` • ${e.sku}` : ""}{!e.url && e.region ? " • no Dataverse" : ""}{envCount(e.id) !== undefined ? ` • ${envCount(e.id)} items scanned` : ""}</div></div>
              </div>))}
            </div>)}
        </div>
        {envQ.trim() && <button className="dl primary" disabled={busy || !envMatches.length} onClick={() => run(envQ)}>⚡ Scan {envMatches.length} matching env{envMatches.length === 1 ? "" : "s"}</button>}
        {busy && <button className="ghost" onClick={() => { cancel.current = true; }}>Stop</button>}
        <button className={autoScan ? "chip chip-on" : "chip chip-btn"} style={{ alignSelf: "center" }} onClick={() => setAutoScan(a => !a)}>
          ⟳ Auto-rescan {autoScan ? "ON (15m)" : "off"}
        </button>
      </section>

      {(busy || agents.length > 0) && (
        <section className="progress">
          <div className="bar"><div className="fill" style={{ width: `${busy ? pct : 100}%` }} /></div>
          <div className="bar-meta">{busy ? <>{prog.msg} — {prog.done}/{prog.total} ({pct}%)</> :
            <>Scan complete — {real.length} items in {envList.length} environments{notes.length ? ` • ${notes.join(" • ")}` : ""}{deltaMsg ? ` • ${deltaMsg}` : ""}</>}</div>
        </section>
      )}
      {error && <div className="err">{error}<div className="sub" style={{ marginTop: 6 }}>If this mentions a connection, open the app's ⋯ → Connections and sign the connection in, or rerun deploy.ps1.</div></div>}

      {agents.length > 0 && (<>
        <section className="summary">
          <div className="chip cs"><b>{count("Copilot Studio")}</b> Copilot Studio</div>
          <div className="chip ab"><b>{count("Agent Builder")}</b> Agent Builder</div>
          <div className="chip sa"><b>{count("Child Agent")}</b> Child agents</div>
          <div className="chip"><b>{agents.filter(a => a.relation === "Connected").length}</b> Connected links</div>
          <div className="chip"><b>{count("Classic (V1)")}</b> Classic (V1)</div>
          <div className="chip m3"><b>{count("Flow")}</b> Flows</div>
          <div className="chip"><b>{real.filter(a => a.autonomous).length}</b> ⚡ Autonomous</div>
          <div className="chip"><b>{findings.length}</b> 🔒 with findings</div>
        </section>
        <section className="summary">
          <div className="tabs">{TABS.map(([t, l]) => <button key={t} className={tab === t ? "tab on" : "tab"} onClick={() => setTab(t)}>{l}</button>)}</div>
          <div className="spacer" />
          <button className="dl" onClick={exportCsv}>⬇ CSV</button>
          <button className="dl" onClick={exportPdf}>⬇ PDF</button>
          <button className="dl primary" onClick={openMail} title="Email this report (CSV + PDF)">📧 Email report</button>
          <button className="dl" onClick={() => setRecert({ scope: "stale", days: 14, sending: false, done: 0, log: [] })} title="Email every owner a list of their agents to KEEP or RETIRE">📨 Recertify owners</button>
          <button className="dl" onClick={schedule}>🗓 Schedule</button>
          <button className="dl" onClick={() => navigator.clipboard.writeText(
            `📊 PNC AI Agent Hub (${new Date().toLocaleDateString()})\n` + insightRows().map(r => `• ${r[0]}: ${r[1]}`).join("\n")).then(() => alert("📋 Copied"))}>📋 Copy</button>
        </section>
        {tab === "owner" && (
          <section className="toolbar ownerbar">
            <div style={{ flex: 1, minWidth: 320 }}>
              <PeoplePicker single value={ownerSel} onChange={setOwnerSel} search={findPeople} local={localPeople} placeholder="👤 Start typing an owner's name or email — suggestions appear instantly" />
            </div>
            {ownerSel[0] && <button className="clear" onClick={() => setOwnerSel([])}>Clear</button>}
            {ownerSel[0] && <div className="count">{view.length} owned item{view.length === 1 ? "" : "s"}</div>}
          </section>
        )}
        {tab === "owner" && !ownerSel[0] && (
          <section className="treewrap"><div className="inscard"><div className="institle">Owners found by the scan — click one</div>
            <div className="ownergrid">{knownOwners.map(p => ({ p, n: agents.filter(a => (a.ownerEmail || a.owner) === p.email).length }))
              .sort((a, b) => b.n - a.n).slice(0, 30).map(({ p, n }) => (
                <button key={p.email} className="ownerchip" onClick={() => setOwnerSel([p.email])}>
                  <span className="ppav">{(p.name || p.email).split(/\s+/).map(w => w[0]).slice(0, 2).join("").toUpperCase()}</span>
                  <span><b>{p.name || p.email}</b><br /><span className="sub">{p.email !== p.name ? p.email : ""} • {n}</span></span>
                </button>))}</div></div></section>
        )}
        {tab === "owner" && ownerSel[0] && (
          <section className="summary">{(["Copilot Studio", "Agent Builder", "Child Agent", "Classic (V1)", "Flow"] as Kind[]).map(k =>
            <div key={k} className={`chip ${PILL[k]}`}><b>{view.filter(a => a.kind === k && a.relation !== "Connected").length}</b> {k}</div>)}
            <div className="chip"><b>{view.filter(a => a.relation === "Connected").length}</b> Connected links</div>
            <div className="chip"><b>{view.filter(a => (riskById.get(a.id)?.score ?? 0) >= 60).length}</b> 🎯 high exposure</div>
          </section>
        )}
        {!["insights", "security", "map", "watch", "lifecycle", "atlas", "sprawl"].includes(tab) && !(tab === "owner" && !ownerSel[0]) && (
          <section className="toolbar">
            <select className="envsel" value={envF} onChange={e => setEnvF(e.target.value)}>
              <option value="all">{envQ.trim() ? `Environments matching “${envQ.trim()}”` : "All environments"}</option>
              {envList.filter(e => !envQ.trim() || e.name.toLowerCase().includes(envQ.trim().toLowerCase()) || e.id === envF).map(e => <option key={e.id} value={e.id}>{e.name} ({e.n})</option>)}
            </select>
            <input className="search" placeholder="Search agents, owner name/email, parent, schema…" value={q} onChange={e => setQ(e.target.value)} />
            <div className="count">{view.length} shown</div>
          </section>
        )}

        {tab === "tree" ? <Tree items={view} all={real} onOpen={openDetail} register={fn => (treeExport.current = fn)} /> :
         tab === "map" ? <AgentMap agents={agents} onOpen={openDetail} /> :
         tab === "owner" && !ownerSel[0] ? null :
         tab === "watch" ? <Watch items={scored.filter(x => envScope(x.a))} onOpen={openDetail} /> :
         tab === "atlas" ? <Atlas rows={atlasRows} scope={envScope} onOpen={openDetail} /> :
         tab === "sprawl" ? <Sprawl clusters={sprawlCl} scope={envScope} onOpen={openDetail} /> :
         tab === "lifecycle" ? <Lifecycle items={lives.filter(x => envScope(x.a))} filter={lifeF} setFilter={setLifeF} onOpen={openDetail} /> :
         tab === "insights" ? <Insights rows={insightRows()} real={real} envList={envList} /> :
         tab === "security" ? (
          <section className="treewrap">
            {findings.length === 0 && <div className="empty">🎉 No findings.</div>}
            {findings.map(({ a, f }) => (
              <div className="treecard" key={a.id}>
                <div className="treeparent">
                  <span className="treeicon">🔒</span>
                  <div><div className="strong">{a.name}{quar[a.id] && <span className="qtag q">QUARANTINED</span>}</div>
                    <div className="sub">{a.kind} • {a.envName} • {a.owner || "no owner"}{a.ownerEmail ? ` (${a.ownerEmail})` : ""} • auth: {a.authMode || "unknown"}</div></div>
                  <span className="kidcount">{f.length} finding{f.length > 1 ? "s" : ""}</span>
                  <button className="rowbtn" onClick={() => openDetail(a)}>Details / quarantine</button>
                </div>
                <div className="treekids">{f.map(([c, l], i) => <div className="treekid" key={i}><span className="treeicon small">⚠</span><div><div>{l}</div><div className="sub mono">{c}</div></div></div>)}</div>
              </div>
            ))}
          </section>
        ) : (
          <section className="grid"><table>
            <thead><tr>
              <th className="srt" onClick={() => sortBy("name")}>Agent{arrow("name")}</th>
              <th className="srt" onClick={() => sortBy("kind")}>Type{arrow("kind")}</th>
              <th className="srt" onClick={() => sortBy("envName")}>Environment{arrow("envName")}</th>
              <th className="srt" onClick={() => sortBy("owner")}>Owner{arrow("owner")}</th>
              <th className="srt" onClick={() => sortBy("createdOn")}>Created{arrow("createdOn")}</th>
              <th className="srt" onClick={() => sortBy("modifiedOn")}>Modified{arrow("modifiedOn")}</th>
              <th>Actions</th>
            </tr></thead>
            <tbody>{view.map(a => (
              <tr key={a.id}>
                <td className="strong">
                  <span className={pins.has(a.id) ? "star on" : "star"} onClick={() => togglePin(a.id)}>★</span>{a.name}
                  {newIds.has(a.id.toLowerCase()) && <span className="pill new">NEW</span>}
                  {quar[a.id] && <span className="qtag q">QUARANTINED</span>}
                  {a.parentName && <div className="sub">child of {a.parentName}</div>}
                </td>
                <td><span className={`pill ${PILL[a.kind]}`}>{a.kind}</span>{a.autonomous && <span className="pill auto">⚡</span>}
                  {riskById.get(a.id) && riskById.get(a.id)!.band !== "Low" && <span className={`risk ${riskById.get(a.id)!.band}`} title={riskById.get(a.id)!.reasons.join("\n")}>🎯 {riskById.get(a.id)!.score}</span>}</td>
                <td>{a.envName}</td><td><span className="ownerlink" onClick={() => { if (a.ownerEmail || a.owner) { setOwnerSel([a.ownerEmail || a.owner]); setTab("owner"); } }}>{a.owner || "—"}</span>{a.ownerDisabled && <span className="pill new" title="Owner account disabled">DISABLED</span>}{a.ownerEmail && <div className="sub">{a.ownerEmail}</div>}</td>
                <td className="mono">{day(a.createdOn)}</td><td className="mono">{day(a.modifiedOn)}</td>
                <td>{<button className="rowbtn" onClick={() => openDetail(a)}>Details</button>}
                  {studioLink(a) && <a className="rowlink" href={studioLink(a)} target="_blank" rel="noreferrer" title={a.linkLabel}>↗</a>}</td>
              </tr>))}
            </tbody></table>
            {!view.length && <div className="empty">No items in this view.</div>}
          </section>
        )}
        {skipped.length > 0 && <details className="skips"><summary>{skipped.length} environment(s) skipped</summary><ul>{skipped.map((s, i) => <li key={i}>{s}</li>)}</ul></details>}
      </>)}

      {!agents.length && !busy && (
        <div className="hero">
          <HubLogo size={190} />
          <h2 className="herotitle">PNC <span>AI Agent</span> Hub</h2>
          <div className="herosub">Every AI agent in the tenant — Copilot Studio, Agent Builder, child & connected agents — in one scan.</div>
            <button className="scan all herobtn" onClick={() => run()}>🔎 Scan tenant now</button>
        <div className="hint" style={{ margin: "18px auto 0", textAlign: "center" }}>One click scans every environment through your own Power Platform connections — no app registration, no Azure resources.
          Finds Copilot Studio agents, Agent Builder agents, child agents (and which parent owns them), connected agents, Classic V1 bots and flows.
          {!hasInventory() && <> (Add the Power Platform for Admins V2 connector via deploy.ps1 for authoritative Agent Builder detection.)</>}</div>
        </div>
      )}

      {detail && (
        <div className="drawerwrap" onClick={() => setDetail(null)}>
          <div className="drawer" onClick={e => e.stopPropagation()}>
            <h2>{detail.name}</h2>
            <div className="sub"><span className={`pill ${PILL[detail.kind]}`}>{detail.kind}</span> {detail.relation && `• ${detail.relation} of ${detail.parentName}`}</div>
            <div className="kv">
              <div>Environment</div><div>{detail.envName}</div>
              <div>Owner</div><div>{detail.owner || "—"}{detail.ownerDisabled && <span className="pill new">DISABLED</span>}{detail.ownerEmail && <> • <a className="rowlink" href={`mailto:${detail.ownerEmail}`}>{detail.ownerEmail}</a></>}
                {(detail.ownerEmail || detail.owner) && <button className="rowbtn" style={{ marginLeft: 8 }} onClick={() => { setOwnerSel([detail.ownerEmail || detail.owner]); setTab("owner"); setDetail(null); }}>All agents by owner</button>}</div>
              <div>Lifecycle</div><div>{(() => { const l = lifeOf(detail); return `${LIFE_INFO[l][0]} ${l} — ${LIFE_INFO[l][1]}`; })()}</div>
              {riskById.get(detail.id) && <><div>🎯 Exposure score</div><div><span className={`risk ${riskById.get(detail.id)!.band}`}>{riskById.get(detail.id)!.score} • {riskById.get(detail.id)!.band}</span>
                <div className="sub">{riskById.get(detail.id)!.reasons.join(" • ") || "no exposure signals"}</div></div></>}
              {detail.source && <><div>Detected via</div><div>{detail.source}</div></>}
              <div>Authentication</div><div>{detail.authMode || "—"}</div>
              <div>Created / Modified</div><div>{day(detail.createdOn)} / {day(detail.modifiedOn)}</div>
              <div>Published</div><div>{day(detail.publishedOn) || "never"}</div>
              <div>Schema</div><div className="mono">{detail.schema}</div>
              {detail.details && <>
                <div>Knowledge sources</div><div>{detail.details.knowledge}</div>
                <div>Autonomous triggers</div><div>{detail.details.triggers}</div>
                <div>Child agents</div><div>{detail.details.children.join(", ") || "—"}</div>
                <div>Connected agents</div><div>{detail.details.connected.join(", ") || "—"}</div>
                <div>Tools / actions</div><div>{detail.details.tools.join(", ") || "—"}</div>
              </>}
            </div>
            {detail.details && detail.kind !== "Flow" && <>
              <div className="sect">🧬 Capabilities — connectors, skills & more</div>
              <CapabilityGraph a={detail} />
            </>}
            {detail.details?.instructions && <>
              <div className="sect">Instructions (system prompt)</div>
              <div className="instr">{detail.details.instructions}</div>
              <button className="rowbtn" style={{ marginTop: 8 }} onClick={() => navigator.clipboard.writeText(detail.details!.instructions)}>Copy instructions</button>
            </>}
            {hasQuarantine() && detail.kind !== "Child Agent" && detail.kind !== "Flow" && (<>
              <div className="sect">Containment</div>
              <div className="sub" style={{ marginBottom: 8 }}>Status: {quar[detail.id] === undefined ? "checking…" : quar[detail.id] === null ? "unknown" : quar[detail.id] ? "⛔ quarantined" : "✅ active"}</div>
              <button className={quar[detail.id] ? "qbtn off" : "qbtn on"} disabled={qBusy === detail.id} onClick={() => toggleQuarantine(detail)}>
                {qBusy === detail.id ? "Working…" : quar[detail.id] ? "Release from quarantine" : "⛔ Quarantine this agent"}
              </button>
            </>)}
            <div className="sect">Open in console</div>
            {detail.kind === "Agent Builder" && <div className="sub" style={{ marginBottom: 8 }}>Agent Builder agents are hidden from Copilot Studio by design. Manage them in the Microsoft 365 admin center ▸ Agents ▸ All agents (filter Platform = Agent Builder, search “{detail.name}” — name copied to clipboard when you click).</div>}
            <div className="consolelinks">
              {(detail.links?.length ? detail.links : studioLink(detail) ? [{ label: detail.linkLabel, url: studioLink(detail) }] : []).map((l, i) =>
                <a key={i} className={i === 0 ? "dl primary" : "dl"} href={l.url} target="_blank" rel="noreferrer"
                  onClick={() => { if (detail.kind === "Agent Builder") navigator.clipboard?.writeText(detail.name).catch(() => {}); }}>↗ {l.label}</a>)}
            </div>
            <div style={{ marginTop: 14, display: "flex", gap: 10 }}>
              <button className="clear" onClick={() => setDetail(null)}>Close</button>
            </div>
          </div>
        </div>
      )}

      {mail && (
        <div className="modalwrap" onClick={() => !mail.sending && setMail(null)}>
          <div className="modal" onClick={e => e.stopPropagation()} style={{ minWidth: 420 }}>
            <h2>📧 Email “{REPORT_NAME[tab]}” report</h2>
            <div className="field">To — type a name or email, pick from the directory
              <PeoplePicker value={mail.to} onChange={v => setMail(m => (m ? { ...m, to: v } : m))} search={findPeople} local={localPeople} />
              <div className="sub" style={{ marginTop: 4 }}>{hasPeople() ? "Directory search via Office 365 Users" : "Directory search via Dataverse users"}</div></div>
            <label className="field">Subject<input value={mail.subject} onChange={e => setMail({ ...mail, subject: e.target.value })} /></label>
            <div className="checks">
              <label><input type="checkbox" checked={mail.csv} onChange={e => setMail({ ...mail, csv: e.target.checked })} /> Attach CSV</label>
              <label><input type="checkbox" checked={mail.pdf} onChange={e => setMail({ ...mail, pdf: e.target.checked })} /> Attach PDF</label>
            </div>
            {!hasMail() && <div className="sub" style={{ color: "var(--bad)" }}>Office 365 Outlook connection not added yet — create it and rerun deploy.ps1.</div>}
            <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
              <button className="signin" disabled={mail.sending || !mail.to.length || (!mail.csv && !mail.pdf)} onClick={sendReport}>{mail.sending ? "Sending…" : "Send"}</button>
              <button className="clear" disabled={mail.sending} onClick={() => setMail(null)}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {recert && (() => {
        const items = recertItems(recert.scope); const owners = groupByOwner(items);
        const noOwner = items.filter(x => !/@/.test(x.a.ownerEmail) || x.a.ownerDisabled);
        let hist: any[] = []; try { hist = JSON.parse(localStorage.getItem("aih-recert") || "[]"); } catch { }
        return (
          <div className="modalwrap" onClick={() => !recert.sending && setRecert(null)}>
            <div className="modal" onClick={e => e.stopPropagation()} style={{ minWidth: 560, maxWidth: 760 }}>
              <h2>📨 Owner Recertification campaign</h2>
              <div className="sub">Like an access review for AI agents: each owner gets one email listing their agents and replies KEEP or RETIRE. You get a tracker CSV to record answers.</div>
              <div className="recertscopes">
                {([["stale", "♻ Stale / drafts / dormant"], ["risk", "🎯 High exposure (≥60)"], ["all", "📋 Every agent (full attestation)"]] as const).map(([k, l]) =>
                  <button key={k} className={recert.scope === k ? "lifechip on" : "lifechip"} onClick={() => setRecert({ ...recert, scope: k, log: [] })}>{l}</button>)}
              </div>
              <label className="field">Reply deadline (days)<input type="number" min={1} max={90} value={recert.days} onChange={e => setRecert({ ...recert, days: Math.max(1, +e.target.value || 14) })} /></label>
              <div className="summary" style={{ margin: "10px 0" }}>
                <div className="chip"><b>{owners.length}</b> owners to email</div>
                <div className="chip"><b>{owners.reduce((n, o) => n + o.items.length, 0)}</b> agents covered</div>
                <div className="chip riskc High"><b>{noOwner.length}</b> 🕳 no reachable owner (admin action)</div>
              </div>
              <div className="recertlist">{owners.slice(0, 50).map(o => (
                <div key={o.email} className="ppitem"><span className="ppav">{(o.name || o.email).split(/\s+/).map(w => w[0]).slice(0, 2).join("").toUpperCase()}</span>
                  <div style={{ flex: 1 }}><div className="strong">{o.name || o.email} <span className="sub">{o.email}</span></div>
                    <div className="sub">{o.items.map(x => x.a.name).join(" • ")}</div></div><b>{o.items.length}</b></div>))}
                {!owners.length && <div className="empty">No agents with a reachable owner in this scope.</div>}
              </div>
              {recert.log.length > 0 && <div className="instr" style={{ maxHeight: 140, overflow: "auto" }}>{recert.log.join("\n")}</div>}
              <div style={{ display: "flex", gap: 10, marginTop: 14, flexWrap: "wrap" }}>
                <button className="dl" disabled={recert.sending || !owners.length} onClick={() => runRecert(true)}>👁 Send test to me</button>
                <button className="signin" disabled={recert.sending || !owners.length} onClick={() => runRecert(false)}>{recert.sending ? `Sending ${recert.done}/${owners.length}…` : `📨 Send to ${owners.length} owner(s)`}</button>
                <button className="clear" disabled={recert.sending} onClick={() => setRecert(null)}>Close</button>
              </div>
              {hist.length > 0 && <><div className="sect">Past campaigns</div>{hist.slice(0, 5).map((h, i) =>
                <div key={i} className="sub">{new Date(h.when).toLocaleString()} • {h.scope} • {h.owners} owners / {h.agents} agents • due {h.due}</div>)}</>}
            </div>
          </div>);
      })()}

      {idq && (
        <div className="modalwrap" onClick={() => !idq.busy && setIdq(null)}>
          <div className="modal" onClick={e => e.stopPropagation()} style={{ minWidth: 560, maxWidth: 760 }}>
            <h2>🆔 Identify any agent by ID</h2>
            <div className="sub">Paste a bot id, child-agent (component) id, flow id, schema name, or a Copilot Studio / Power Automate URL.</div>
            <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
              <input className="search" style={{ flex: 1 }} autoFocus placeholder="e.g. 3f2a…-…  or  cr26e_hrHelper  or  https://copilotstudio.microsoft.com/…/bots/…"
                value={idq.q} onChange={e => setIdq({ ...idq, q: e.target.value, searched: false })} onKeyDown={e => e.key === "Enter" && runIdLookup(false)} />
              <button className="signin" disabled={idq.busy || !idq.q.trim()} onClick={() => runIdLookup(false)}>Identify</button>
            </div>
            {idq.msg && <div className="sub" style={{ marginTop: 8 }}>{idq.busy ? "⏳ " : ""}{idq.msg}</div>}
            {[...idq.local.map(a => ({ a, how: "found in scan", live: false })), ...idq.live.map(h => ({ a: h.agent, how: `live: ${h.how}`, live: true }))].map(({ a, how, live }, i) => {
              const [ic, role, desc] = roleOf(a);
              return (
                <div key={i} className="idcard">
                  <div className="idrole"><span className="idicon">{ic}</span><div><div className="idrolename">{role}</div><div className="sub">{desc}</div></div></div>
                  <div className="kv">
                    <div>Name</div><div className="strong">{a.name}</div>
                    <div>Environment</div><div>{a.envName}</div>
                    <div>Owner</div><div>{a.owner || "—"}{a.ownerEmail ? ` (${a.ownerEmail})` : ""}</div>
                    {a.parentName && <><div>Parent</div><div>{a.parentName} <span className="mono sub">{a.parentId}</span></div></>}
                    <div>Agent id</div><div className="mono">{a.id.split("|")[0]} <button className="rowbtn" onClick={() => navigator.clipboard.writeText(a.id.split("|")[0])}>Copy</button></div>
                    {a.schema && <><div>Schema</div><div className="mono">{a.schema}</div></>}
                    <div>Environment id</div><div className="mono">{a.envId}</div>
                    <div>Matched by</div><div className="sub">{how}</div>
                  </div>
                  <div className="consolelinks" style={{ flexDirection: "row", flexWrap: "wrap", marginTop: 8 }}>
                    {!live && <button className="dl primary" onClick={() => { setIdq(null); openDetail(a); }}>🔍 Open full details</button>}
                    {(a.links ?? []).slice(0, 2).map((l, j) => <a key={j} className="dl" href={l.url} target="_blank" rel="noreferrer">↗ {l.label}</a>)}
                  </div>
                </div>);
            })}
            {idq.searched && !idq.busy && (
              <div style={{ display: "flex", gap: 10, marginTop: 12, alignItems: "center" }}>
                {!idq.local.length && !idq.live.length && !idq.msg && <span className="sub">Not in the current scan.</span>}
                <button className="dl" disabled={idq.busy} onClick={() => runIdLookup(true)}>🌐 Search all {allEnvs.filter(e => e.url).length} environments live</button>
              </div>)}
            <div style={{ marginTop: 14 }}><button className="clear" disabled={idq.busy} onClick={() => setIdq(null)}>Close</button></div>
          </div>
        </div>
      )}

      <footer className="footer">
        <svg width="26" height="26" viewBox="0 0 32 32" aria-hidden="true">
          <rect x="6" y="9" width="20" height="16" rx="6" fill="#F27A21" />
          <circle cx="12.5" cy="17" r="2.2" fill="#fff" /><circle cx="19.5" cy="17" r="2.2" fill="#fff" />
          <path d="M12.5 21.5 Q16 23.5 19.5 21.5" stroke="#fff" strokeWidth="1.6" fill="none" strokeLinecap="round" />
          <line x1="16" y1="9" x2="16" y2="5" stroke="#F27A21" strokeWidth="2" /><circle cx="16" cy="4" r="2" fill="#0B2B4C" />
          <path d="M27 6 l1 2.2 2.2 1 -2.2 1 -1 2.2 -1 -2.2 -2.2 -1 2.2 -1z" fill="#ffd166" />
        </svg>
        <span>Created by <b>Kirolos</b> • Power of Automation</span>
      </footer>

      {showAbout && (
        <div className="modalwrap" onClick={() => setShowAbout(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <h2>PNC AI Agent Hub</h2>
            <ul className="aboutlist">
              <li><b>One Code App, no app registration:</b> every call runs through the signed-in admin's Power Platform connections.</li>
              <li><b>Every agent type:</b> Copilot Studio, Agent Builder, child agents (<span className="mono">kind: AgentDialog</span>), connected agents, Classic V1, flows.</li>
              <li><b>Identify & analyse:</b> 🆔 find any agent / child / connected / lite / flow by ID or URL, 🔌 Connector Atlas (DLP risk tiers), 👯 Sprawl (duplicate agents).</li>
              <li><b>Recertify:</b> 📨 owner recertification campaigns (KEEP / RETIRE emails + tracker CSV).</li>
              <li><b>Govern:</b> 👤 owner lookup by email, 🎯 Agents-to-Watch exposure score, ♻ lifecycle (orphaned / zombie / stale) with growth timeline.</li>
              <li><b>Act, not just report:</b> agent detail drawer with instructions & tools, one-click quarantine.</li>
              <li><b>Data stays in your tenant.</b> Build {BUILD_STAMP}.</li>
            </ul>
            <button className="signin" onClick={() => setShowAbout(false)}>Close</button>
          </div>
        </div>
      )}
    </div>
  );
}

/* -------------------------- Parent ↔ Child tree -------------------------- */
function Tree({ items, all, onOpen, register }: { items: Agent[]; all: Agent[]; onOpen: (a: Agent) => void; register: (fn: (pdf: boolean) => void) => void }) {
  const groups = new Map<string, Agent[]>();
  items.forEach(a => { const k = `${a.envId}|${a.parentId}`; if (!groups.has(k)) groups.set(k, []); groups.get(k)!.push(a); });
  const fams = [...groups.values()].sort((a, b) => b.length - a.length);
  const exportRel = (pdf: boolean) => {
    const header = ["Environment", "Parent Agent", "Parent Agent ID", "Parent Owner Name", "Parent Owner Email", "Child / Connected Agent", "Child / Connected Agent ID", "Relationship", "Created", "Environment ID", "Open Link"];
    const rows = fams.flatMap(k => k.map(c => { const p = all.find(x => x.id === c.parentId);
      return [c.envName, c.parentName, c.parentId, p?.owner ?? c.owner, p?.ownerEmail ?? c.ownerEmail, c.name, c.id.split("|")[0], c.relation, day(c.createdOn), c.envId, c.link]; }))
      .sort((a, b) => a[0].localeCompare(b[0]) || a[1].localeCompare(b[1]) || a[5].localeCompare(b[5]));
    if (pdf) pdfDownload("Parent ↔ Child Agent Report", `Generated ${new Date().toLocaleString()} • ${fams.length} parents • ${items.length} links`, header.slice(0, 9), rows.map(r => r.slice(0, 9)), `parent-child-${stamp()}.pdf`);
    else csvDownload(`parent-child-${stamp()}.csv`, header, rows);
  };
  register(exportRel);
  return (
    <section className="treewrap">
      <div className="treestats">
        <div className="chip"><b>{fams.length}</b> parent agents</div>
        <div className="chip sa"><b>{items.length}</b> child / connected</div>
        <div className="spacer" />
        <button className="dl" onClick={() => exportRel(false)}>⬇ Relationship CSV</button>
        <button className="dl" onClick={() => exportRel(true)}>⬇ Relationship PDF</button>
      </div>
      {!fams.length && <div className="empty">No parent → child relationships found.</div>}
      {fams.map(kids => {
        const p = all.find(a => a.id === kids[0].parentId);
        return (
          <div className="treecard" key={kids[0].envId + kids[0].parentId}>
            <div className="treeparent">
              <span className="treeicon">🤖</span>
              <div><div className="strong">{kids[0].parentName}</div><div className="sub">{p?.kind ?? "Copilot Studio"} • {kids[0].envName} • {p?.owner || "owner unknown"}</div></div>
              <span className="kidcount">{kids.length} linked</span>
              {p && <button className="rowbtn" onClick={() => onOpen(p)}>Details</button>}
            </div>
            <div className="treekids">{kids.map(c => (
              <div className="treekid" key={c.id}><span className="treeicon small">↳</span>
                <div><div className="strong">{c.name}</div><div className="sub">{c.relation === "Child" ? "Child agent (inside parent)" : "Connected agent (separate bot)"} • created {day(c.createdOn) || "—"}</div></div>
              </div>))}
            </div>
          </div>);
      })}
    </section>
  );
}

/* ------------------------------- Insights -------------------------------- */
function Insights({ rows, real, envList }: { rows: string[][]; real: Agent[]; envList: { id: string; name: string; n: number }[] }) {
  const kinds: [string, number, string][] = ([["Copilot Studio", "#4cc2ff"], ["Agent Builder", "#ffb454"], ["Child Agent", "#c99bff"], ["Classic (V1)", "#9fb0c9"], ["Flow", "#5fd4c4"]] as [Kind, string][])
    .map(([k, c]) => [k, real.filter(a => a.kind === k).length, c] as [string, number, string]).filter(k => k[1] > 0);
  const total = kinds.reduce((n, k) => n + k[1], 0) || 1;
  const C = 2 * Math.PI * 60; let acc = 0;
  const max = Math.max(1, ...envList.map(e => e.n));
  const owners = new Map<string, number>();
  real.filter(a => a.kind !== "Flow").forEach(a => a.owner && owners.set(a.owner, (owners.get(a.owner) ?? 0) + 1));
  return (
    <section className="treewrap">
      <div className="insrow">
        <div className="inscard"><div className="institle">Agent mix</div>
          <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
            <svg width="150" height="150" viewBox="0 0 150 150">{kinds.map((k, i) => {
              const f = k[1] / total, o = acc; acc += f;
              return <circle key={i} cx="75" cy="75" r="60" fill="none" stroke={k[2]} strokeWidth="22" strokeDasharray={`${f * C} ${C}`} strokeDashoffset={-o * C} transform="rotate(-90 75 75)" />;
            })}<text x="75" y="80" textAnchor="middle" fill="#e8eef9" fontSize="22" fontWeight="700">{total}</text></svg>
            <div>{kinds.map((k, i) => <div key={i} className="legend"><span className="dotc" style={{ background: k[2] }} />{k[0]} — <b>{k[1]}</b></div>)}</div>
          </div></div>
        <div className="inscard"><div className="institle">Key numbers</div>{rows.map((r, i) => <div className="flag" key={i}>{r[0]}: <b>{r[1]}</b></div>)}</div>
      </div>
      <div className="insrow">
        <div className="inscard" style={{ flex: 2 }}><div className="institle">Agents per environment</div>
          {envList.map(e => <div key={e.id} className="envbar"><span className="envbarlabel">{e.name}</span><div className="envbartrack"><div className="envbarfill" style={{ width: `${(e.n / max) * 100}%` }} /></div><b>{e.n}</b></div>)}</div>
        <div className="inscard"><div className="institle">👑 Top owners</div>
          {[...owners.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6).map(([o, n], i) => <div className="flag" key={i}>{i + 1}. {o} — <b>{n}</b></div>)}</div>
      </div>
    </section>
  );
}

/* --------------------------- 🎯 Agents to Watch --------------------------- */
function Watch({ items, onOpen }: { items: { a: Agent; r: ReturnType<typeof riskOf> }[]; onOpen: (a: Agent) => void }) {
  const n = (b: string) => items.filter(x => x.r.band === b).length;
  return (
    <section className="treewrap">
      <div className="treestats">
        <div className="chip riskc High"><b>{n("High")}</b> High (≥60)</div>
        <div className="chip riskc Medium"><b>{n("Medium")}</b> Medium</div>
        <div className="chip riskc Low"><b>{n("Low")}</b> Low</div>
        <div className="spacer" /><div className="sub">Score = auth + access + autonomy + tools + knowledge + ownership + Default env</div>
      </div>
      {items.filter(x => x.r.score > 0).slice(0, 60).map(({ a, r }, i) => (
        <div className="watchrow" key={a.id} onClick={() => onOpen(a)}>
          <div className="rank">#{i + 1}</div>
          <div className={`gauge ${r.band}`} style={{ ["--p" as any]: r.score }}><span>{r.score}</span></div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="strong">{a.name} <span className={`pill ${PILL[a.kind]}`}>{a.kind}</span></div>
            <div className="sub">{a.envName} • {a.owner || "no owner"}{a.ownerEmail ? ` (${a.ownerEmail})` : ""}</div>
            <div className="reasons">{r.reasons.map((x, j) => <span key={j} className="reason">{x}</span>)}</div>
          </div>
          <div className="scorebar"><div className={`scorefill ${r.band}`} style={{ width: `${r.score}%` }} /></div>
        </div>))}
      {!items.some(x => x.r.score > 0) && <div className="empty">🎉 No exposure signals.</div>}
    </section>
  );
}

/* ------------------------------ ♻ Lifecycle ------------------------------ */
function Lifecycle({ items, filter, setFilter, onOpen }: { items: { a: Agent; l: Life }[]; filter: Life | "all"; setFilter: (l: Life | "all") => void; onOpen: (a: Agent) => void }) {
  const g = growth(items.map(x => x.a).filter(a => a.kind !== "Flow"));
  const max = Math.max(1, ...g.map(x => Math.max(x.created, x.published)));
  const W = 720, H = 170, bw = W / g.length;
  const shown = items.filter(x => filter === "all" || x.l === filter)
    .sort((x, y) => LIFE_ORDER.indexOf(x.l) - LIFE_ORDER.indexOf(y.l) || x.a.name.localeCompare(y.a.name));
  return (
    <section className="treewrap">
      <div className="lifechips">
        <button className={filter === "all" ? "lifechip on" : "lifechip"} onClick={() => setFilter("all")}><b>{items.length}</b> All</button>
        {LIFE_ORDER.map(l => (
          <button key={l} className={filter === l ? "lifechip on" : "lifechip"} onClick={() => setFilter(l)} title={LIFE_INFO[l][1]}>
            <span>{LIFE_INFO[l][0]}</span><b>{items.filter(x => x.l === l).length}</b> {l}
          </button>))}
      </div>
      <div className="inscard"><div className="institle">📈 Agent growth — last 12 months (<span style={{ color: "#F27A21" }}>■ created</span> vs <span style={{ color: "#4cc2ff" }}>■ published</span>)</div>
        <svg viewBox={`0 0 ${W} ${H + 24}`} width="100%" style={{ maxHeight: 230 }}>
          {g.map((x, i) => {
            const hc = (x.created / max) * H, hp = (x.published / max) * H;
            return <g key={x.m}>
              <rect x={i * bw + bw * .14} y={H - hc} width={bw * .34} height={hc} rx="3" fill="#F27A21"><title>{x.m}: {x.created} created</title></rect>
              <rect x={i * bw + bw * .52} y={H - hp} width={bw * .34} height={hp} rx="3" fill="#4cc2ff"><title>{x.m}: {x.published} published</title></rect>
              {x.created > 0 && <text x={i * bw + bw * .31} y={H - hc - 4} textAnchor="middle" className="glabel">{x.created}</text>}
              <text x={i * bw + bw / 2} y={H + 16} textAnchor="middle" className="glabel">{x.m.slice(2)}</text>
            </g>;
          })}
        </svg>
      </div>
      <section className="grid"><table>
        <thead><tr><th>Lifecycle</th><th>Agent</th><th>Type</th><th>Environment</th><th>Owner</th><th>Created</th><th>Modified</th><th>Published</th></tr></thead>
        <tbody>{shown.slice(0, 500).map(({ a, l }) => (
          <tr key={a.id} onClick={() => onOpen(a)} style={{ cursor: "pointer" }}>
            <td><span className={`lifetag L${LIFE_ORDER.indexOf(l)}`}>{LIFE_INFO[l][0]} {l}</span></td>
            <td className="strong">{a.name}</td><td><span className={`pill ${PILL[a.kind]}`}>{a.kind}</span></td><td>{a.envName}</td>
            <td>{a.owner || "—"}{a.ownerDisabled && <span className="pill new">DISABLED</span>}</td>
            <td className="mono">{day(a.createdOn)}</td><td className="mono">{day(a.modifiedOn)}</td><td className="mono">{day(a.publishedOn) || "never"}</td>
          </tr>))}</tbody></table>
        {!shown.length && <div className="empty">Nothing in this state.</div>}
      </section>
    </section>
  );
}

/* ---------------------------- 🔌 Connector Atlas ---------------------------- */
const TIER_C: Record<Tier, string> = { High: "#ff4d5e", Custom: "#c99bff", Medium: "#ffb454", Low: "#5fd4c4" };
function Atlas({ rows, scope, onOpen }: { rows: AtlasRow[]; scope: (a: Agent) => boolean; onOpen: (a: Agent) => void }) {
  const [open, setOpen] = useState<string>("");
  const [tf, setTf] = useState<Tier | "all">("all");
  const list = rows.map(r => ({ ...r, agents: r.agents.filter(scope) })).filter(r => r.agents.length);
  const shown = list.filter(r => tf === "all" || r.tier === tf);
  const max = Math.max(1, ...list.map(r => r.agents.length));
  const tiers: Tier[] = ["High", "Custom", "Medium", "Low"];
  const agentsWithHigh = new Set(list.filter(r => r.tier === "High" || r.tier === "Custom").flatMap(r => r.agents)).size;
  return (
    <section className="treewrap">
      <div className="lifechips">
        <button className={tf === "all" ? "lifechip on" : "lifechip"} onClick={() => setTf("all")}><b>{list.length}</b> connectors & endpoints</button>
        {tiers.map(t => <button key={t} className={tf === t ? "lifechip on" : "lifechip"} onClick={() => setTf(t)}>
          <span className="tierdot" style={{ background: TIER_C[t] }} /><b>{list.filter(r => r.tier === t).length}</b> {t === "Custom" ? "Custom connector" : `${t} risk`}</button>)}
        <div className="chip riskc High"><b>{agentsWithHigh}</b> agents touch high-risk / custom</div>
      </div>
      <div className="sub" style={{ marginBottom: 10 }}>Tiers follow Microsoft's DLP guidance: exfiltration-capable connectors (HTTP, SMTP, FTP, consumer storage, social) are High; 🔒 marks connectors DLP policies <b>cannot block</b>.</div>
      {shown.map(r => (
        <div key={r.key} className="atlasrow">
          <div className="atlashead" onClick={() => setOpen(o => (o === r.key ? "" : r.key))}>
            <span className="tierpill" style={{ background: TIER_C[r.tier] + "26", color: TIER_C[r.tier], borderColor: TIER_C[r.tier] }}>{r.tier}</span>
            <span className="strong atlasname">{r.name}{r.unblockable && <span title="DLP cannot block this connector" className="unblk">🔒 unblockable</span>}</span>
            <span className="sub atlaskind">{r.kind}</span>
            <div className="capbartrack"><div className="capbarfill" style={{ width: `${(r.agents.length / max) * 100}%`, background: TIER_C[r.tier] }} /></div>
            <b className="atlasn">{r.agents.length}</b>
            <span className="sub">{open === r.key ? "▲" : "▼"}</span>
          </div>
          {open === r.key && <div className="atlasbody">
            {r.ops.length > 0 && <div className="reasons" style={{ marginBottom: 8 }}>{r.ops.map(o => <span key={o} className="reason">{o}</span>)}</div>}
            {r.agents.map(a => <div key={a.id} className="ppitem" onClick={() => onOpen(a)}>
              <span className="ppav">🤖</span><div style={{ flex: 1 }}><div className="strong">{a.name}</div><div className="sub">{a.envName} • {a.owner || "no owner"}</div></div>
              <span className={`pill ${a.kind === "Agent Builder" ? "ab" : "cs"}`}>{a.kind}</span></div>)}
          </div>}
        </div>))}
      {!list.length && <div className="empty">No connector usage detected (run a new scan — connector data was added in v58).</div>}
    </section>
  );
}

/* -------------------------------- 👯 Sprawl -------------------------------- */
function Sprawl({ clusters, scope, onOpen }: { clusters: Cluster[]; scope: (a: Agent) => boolean; onOpen: (a: Agent) => void }) {
  const list = clusters.map(c => ({ ...c, members: c.members.filter(scope) })).filter(c => c.members.length > 1);
  const dup = list.reduce((n, c) => n + c.members.length - 1, 0);
  return (
    <section className="treewrap">
      <div className="lifechips">
        <div className="chip riskc High"><b>{list.filter(c => c.label === "Twin").length}</b> 👯 twin clusters</div>
        <div className="chip riskc Medium"><b>{list.filter(c => c.label === "Sibling").length}</b> 🧬 sibling clusters</div>
        <div className="chip"><b>{dup}</b> agents that could be consolidated</div>
      </div>
      <div className="sub" style={{ marginBottom: 10 }}>Twins = same normalised name or ≥60% identical instructions; siblings = strongly similar name, instructions or tool set. Consolidate to cut cost, attack surface and owner confusion.</div>
      {list.map((c, i) => (
        <div key={i} className="treecard">
          <div className="treeparent">
            <span className="treeicon">{c.label === "Twin" ? "👯" : "🧬"}</span>
            <div><div className="strong">{c.label} cluster #{i + 1} — {c.members.length} agents</div>
              <div className="sub">{[...new Set(c.pairs.flatMap(p => p.why))].join(" • ")}</div></div>
            <span className="kidcount">{Math.round(c.top * 100)}% similar</span>
          </div>
          <div className="treekids">{c.members.map(m => (
            <div key={m.id} className="treekid" style={{ cursor: "pointer" }} onClick={() => onOpen(m)}><span className="treeicon small">↳</span>
              <div><div className="strong">{m.name} <span className={`pill ${m.kind === "Agent Builder" ? "ab" : m.kind === "Classic (V1)" ? "ot" : "cs"}`}>{m.kind}</span></div>
                <div className="sub">{m.envName} • {m.owner || "no owner"} • modified {(m.modifiedOn || "").slice(0, 10) || "—"}</div></div></div>))}
          </div>
        </div>))}
      {!list.length && <div className="empty">🎉 No duplicate or near-duplicate agents found.</div>}
    </section>
  );
}
