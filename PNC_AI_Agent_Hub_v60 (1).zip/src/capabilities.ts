/* ------------------------------------------------------------------------
   Capability extraction from botcomponent YAML (schema per
   microsoft/skills-for-copilot-studio bot.schema + Microsoft Learn):
   TaskDialog.action.kind = InvokeConnectorTaskAction | InvokeFlowTaskAction |
   InvokeExternalAgentTaskAction (MCP / A2A) | InvokeAIBuilderModelTaskAction |
   InvokeComputerUsingAgentTaskAction | InvokeConnectedAgentTaskAction |
   InvokeAgentTaskAction | InvokeSkillTaskAction | InvokeAIPluginTaskAction.
   Inline topic nodes: InvokeConnectorAction, InvokeFlowAction,
   InvokeMcpToolAction, InvokeAIBuilderModelAction, HttpRequestAction.
------------------------------------------------------------------------ */
export type CapKind = "Connector" | "Flow" | "MCP" | "Agent (A2A)" | "Prompt / AI" | "Computer use" | "Skill" | "HTTP" | "Plugin / REST" | "Client";
export type Cap = { kind: CapKind; name: string; detail: string; ops: string[]; uses: number; api: string };

const CONNECTOR_NAMES: Record<string, string> = {
  office365: "Office 365 Outlook", office365users: "Office 365 Users", office365groups: "Office 365 Groups",
  sharepointonline: "SharePoint", teams: "Microsoft Teams", commondataserviceforapps: "Dataverse",
  onedriveforbusiness: "OneDrive for Business", excelonlinebusiness: "Excel Online", planner: "Planner",
  microsoftforms: "Microsoft Forms", approvals: "Approvals", sql: "SQL Server", azureblob: "Azure Blob Storage",
  servicenow: "ServiceNow", salesforce: "Salesforce", webcontents: "HTTP with Entra ID", outlook: "Outlook.com",
  todo: "Microsoft To Do", kusto: "Azure Data Explorer", azureopenai: "Azure OpenAI", microsoftlearndocsmcpserver: "Microsoft Learn MCP",
  powerplatformforadmins: "Power Platform for Admins", flowmanagement: "Power Automate Management", jira: "Jira",
  github: "GitHub", conversionservice: "Content Conversion", bingsearch: "Bing Search", graph: "Microsoft Graph",
  ftp: "FTP", smtp: "SMTP", sftpwithssh: "SFTP (SSH)", sendmail: "Mail (anonymous)", dropbox: "Dropbox", googledrive: "Google Drive",
  gmail: "Gmail", twitter: "X (Twitter)", slack: "Slack", keyvault: "Azure Key Vault", azuretables: "Azure Table Storage", powerbi: "Power BI", onenote: "OneNote"
};
export const connectorName = (api: string) => {
  const k = api.replace(/^shared_/i, "").toLowerCase();
  if (/-5f/.test(k)) { // custom connector: shared_<publisher>-5f<name>-5f<suffix>  (-5f = encoded "_")
    const parts = k.split("-5f"); const nm = (parts.length >= 3 ? parts.slice(1, -1).join(" ") : parts[parts.length - 1]).replace(/[-_]+/g, " ");
    return nm.replace(/\b\w/g, c => c.toUpperCase()) + " (custom)";
  }
  return CONNECTOR_NAMES[k] ?? k.replace(/[-_]+/g, " ").replace(/\b\w/g, c => c.toUpperCase());
};
const PRETTY_OP = (op: string) => op.replace(/_V\d+$/i, "").replace(/V\d+$/, "").replace(/([a-z])([A-Z])/g, "$1 $2");

/** Parse one component's YAML text and merge findings into `bag`. */
export function extractCaps(data: string, compName: string, bag: Map<string, Cap>) {
  if (!data) return;
  const add = (kind: CapKind, key: string, name: string, detail = "", op = "") => {
    const k = `${kind}|${key.toLowerCase()}`;
    const c = bag.get(k) ?? { kind, name, detail, ops: [], uses: 0, api: key.toLowerCase() };
    c.uses++; if (op && !c.ops.includes(op)) c.ops.push(op);
    bag.set(k, c);
  };
  const near = (from: number, re: RegExp, span = 600) => { const m = data.slice(from, from + span).match(re); return m ? m[1] : ""; };
  const kindAt = (i: number) => { const before = data.slice(Math.max(0, i - 700), i); const all = [...before.matchAll(/kind:\s*(Invoke\w+|HttpRequestAction)/g)]; return all.length ? all[all.length - 1][1] : ""; };
  const display = (data.match(/^modelDisplayName:\s*(.+)$/m)?.[1] ?? compName ?? "").trim();

  // connector & MCP & computer-use refs (3-part or bare API name)
  for (const m of data.matchAll(/connectionReference:\s*(?:[\w-]+\.)?(shared_[a-z0-9_-]+)/gi)) {
    const api = m[1].toLowerCase(), i = m.index ?? 0, k = kindAt(i);
    const op = near(i, /operationId:\s*([\w.\-]+)/);
    if (/ModelContextProtocol/i.test(data.slice(i, i + 600)) || k === "InvokeExternalAgentTaskAction" && !/AgentToAgent/i.test(data.slice(i, i + 600)))
      add("MCP", api, connectorName(api), display, op);
    else if (/AgentToAgent/i.test(data.slice(i, i + 600))) add("Agent (A2A)", api, connectorName(api), display, op);
    else if (k === "InvokeComputerUsingAgentTaskAction") add("Computer use", api, display || "Computer use", connectorName(api), op);
    else add("Connector", api, connectorName(api), display, op ? PRETTY_OP(op) : "");
  }
  // schema-name style references (connectionReferenceSchemaName: cr123_SharedSharePointOnline)
  for (const m of data.matchAll(/connectionReferenceSchemaName:\s*\w*?_?shared_?([a-z0-9]+)/gi)) {
    const api = "shared_" + m[1].toLowerCase();
    add("Connector", api, connectorName(api), display, PRETTY_OP(near(m.index ?? 0, /operationId:\s*([\w.\-]+)/)));
  }
  for (const m of data.matchAll(/flowId:\s*["']?([0-9a-f-]{36})/gi)) add("Flow", m[1], display || "Power Automate flow", m[1]);
  for (const m of data.matchAll(/kind:\s*InvokeMcpToolAction[\s\S]{0,400}?serverSchemaName:\s*([\w.-]+)/gi))
    add("MCP", m[1], m[1], display, near(m.index ?? 0, /toolName:\s*([\w.-]+)/));
  for (const m of data.matchAll(/aIModelId:\s*["']?([0-9a-f-]{36})/gi)) add("Prompt / AI", m[1], display || "AI prompt", "AI Builder model");
  for (const m of data.matchAll(/skillId:\s*["']?([^\s"']+)/gi)) add("Skill", m[1], display || m[1], "Bot Framework skill", near(m.index ?? 0, /actionId:\s*([^\s"']+)/));
  for (const m of data.matchAll(/kind:\s*HttpRequestAction[\s\S]{0,600}?url:\s*["']?([^\s"']+)/gi)) {
    let host = m[1]; try { host = new URL(m[1].replace(/^=/, "")).host; } catch { host = m[1].slice(0, 60); }
    add("HTTP", host, host, display, near(m.index ?? 0, /method:\s*(\w+)/));
  }
  if (/kind:\s*InvokeAIPluginTaskAction/i.test(data)) add("Plugin / REST", display, display || "REST API tool", "AI plugin");
  if (/kind:\s*InvokeClientTaskAction/i.test(data)) add("Client", display, display || "Client action", "client-side");
}

export const CAP_STYLE: Record<CapKind, [string, string]> = {
  "Connector": ["#F27A21", "🔌"], "Flow": ["#5fd4c4", "⚙️"], "MCP": ["#c99bff", "🧩"], "Agent (A2A)": ["#ff8fb1", "🤝"],
  "Prompt / AI": ["#ffd166", "✨"], "Computer use": ["#ff6b7a", "🖱"], "Skill": ["#4cc2ff", "🎓"], "HTTP": ["#9fb0c9", "🌐"],
  "Plugin / REST": ["#8be28b", "🔗"], "Client": ["#b8c4d6", "📱"]
};
