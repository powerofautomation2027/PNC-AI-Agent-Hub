/* 🕸 Agent Map — interactive constellation of the whole tenant:
   tenant core → environments → agents → child/connected agents.
   Pure SVG radial layout, zoom, hover cards, click-through to details. */
import { useMemo, useState } from "react";
import type { Agent } from "./scanner";

const COLOR: Record<string, string> = {
  "Copilot Studio": "#4cc2ff", "Agent Builder": "#F27A21", "Classic (V1)": "#9fb0c9", "Child Agent": "#c99bff", Flow: "#5fd4c4"
};
type Node = { id: string; x: number; y: number; r: number; color: string; label: string; agent?: Agent; kind: string };
type Edge = { x1: number; y1: number; x2: number; y2: number; color: string; dash?: boolean };

export default function AgentMap({ agents, onOpen }: { agents: Agent[]; onOpen: (a: Agent) => void }) {
  const [zoom, setZoom] = useState(1);
  const [hover, setHover] = useState<Node | null>(null);
  const [showFlows, setShowFlows] = useState(false);

  const { nodes, edges } = useMemo(() => {
    const nodes: Node[] = [], edges: Edge[] = [];
    const C = 500;
    const tops = agents.filter(a => !a.relation && (showFlows || a.kind !== "Flow"));
    const envs = [...new Map(tops.map(a => [a.envId, a.envName])).entries()];
    nodes.push({ id: "tenant", x: C, y: C, r: 34, color: "#F27A21", label: "Tenant", kind: "tenant" });
    const R1 = envs.length <= 1 ? 0 : 270;
    envs.forEach(([envId, envName], i) => {
      const ang = (2 * Math.PI * i) / Math.max(envs.length, 1) - Math.PI / 2;
      const ex = C + R1 * Math.cos(ang), ey = C + R1 * Math.sin(ang);
      if (R1) edges.push({ x1: C, y1: C, x2: ex, y2: ey, color: "#F27A21" });
      nodes.push({ id: "env:" + envId, x: ex, y: ey, r: 20, color: "#0B2B4C", label: envName, kind: "env" });
      const mine = tops.filter(a => a.envId === envId);
      const R2 = Math.min(150, 46 + mine.length * 7);
      mine.forEach((a, j) => {
        const t = (2 * Math.PI * j) / Math.max(mine.length, 1) + ang;
        const ax = ex + R2 * Math.cos(t), ay = ey + R2 * Math.sin(t);
        edges.push({ x1: ex, y1: ey, x2: ax, y2: ay, color: COLOR[a.kind] ?? "#888" });
        nodes.push({ id: a.id, x: ax, y: ay, r: a.autonomous ? 10 : 8, color: COLOR[a.kind] ?? "#888", label: a.name, agent: a, kind: a.kind });
        const kids = agents.filter(k => k.relation && k.parentId === a.id);
        kids.forEach((k, m) => {
          const u = t + ((m - (kids.length - 1) / 2) * 0.5);
          const kx = ax + 42 * Math.cos(u), ky = ay + 42 * Math.sin(u);
          edges.push({ x1: ax, y1: ay, x2: kx, y2: ky, color: "#c99bff", dash: k.relation === "Connected" });
          nodes.push({ id: k.id, x: kx, y: ky, r: 6, color: "#c99bff", label: k.name, agent: k, kind: k.relation === "Connected" ? "Connected agent" : "Child agent" });
        });
      });
    });
    return { nodes, edges };
  }, [agents, showFlows]);

  const vb = 1000 / zoom, off = (1000 - vb) / 2;
  return (
    <section className="mapwrap">
      <div className="treestats">
        <div className="chip"><b>{nodes.filter(n => n.kind === "env").length}</b> environments</div>
        <div className="chip"><b>{nodes.filter(n => n.agent && !n.agent.relation).length}</b> agents</div>
        <div className="chip sa"><b>{nodes.filter(n => n.agent?.relation).length}</b> child / connected</div>
        <label className="chip chip-btn"><input type="checkbox" checked={showFlows} onChange={e => setShowFlows(e.target.checked)} /> show flows</label>
        <div className="spacer" />
        <button className="clear" onClick={() => setZoom(z => Math.min(4, z * 1.4))}>＋</button>
        <button className="clear" onClick={() => setZoom(z => Math.max(0.6, z / 1.4))}>－</button>
        <button className="clear" onClick={() => setZoom(1)}>Reset</button>
      </div>
      <div className="mapcanvas">
        <svg viewBox={`${off} ${off} ${vb} ${vb}`} width="100%" style={{ maxHeight: 760 }}>
          <defs><radialGradient id="mapbg" cx="50%" cy="50%" r="60%"><stop offset="0" stopColor="rgba(242,122,33,.10)" /><stop offset="1" stopColor="rgba(0,0,0,0)" /></radialGradient></defs>
          <circle cx="500" cy="500" r="480" fill="url(#mapbg)" />
          {edges.map((e, i) => <line key={i} x1={e.x1} y1={e.y1} x2={e.x2} y2={e.y2} stroke={e.color} strokeOpacity=".45" strokeWidth={1.4} strokeDasharray={e.dash ? "4 4" : undefined} />)}
          {nodes.map(n => (
            <g key={n.id} className="mapnode" onMouseEnter={() => setHover(n)} onMouseLeave={() => setHover(null)}
               onClick={() => n.agent && onOpen(n.agent)} style={{ cursor: n.agent ? "pointer" : "default" }}>
              {n.agent?.autonomous && <circle cx={n.x} cy={n.y} r={n.r + 6} fill="none" stroke="#ffd166" strokeWidth="1.5" className="pulse" />}
              <circle cx={n.x} cy={n.y} r={n.r} fill={n.color} stroke={n.kind === "env" ? "#F27A21" : "rgba(255,255,255,.6)"} strokeWidth={n.kind === "env" ? 3 : 1} />
              {(n.kind === "env" || n.kind === "tenant") &&
                <text x={n.x} y={n.y + n.r + 16} textAnchor="middle" className="maplabel">{n.label}</text>}
            </g>
          ))}
        </svg>
        {hover && hover.agent && (
          <div className="maptip" style={{ left: `${((hover.x - off) / vb) * 100}%`, top: `${((hover.y - off) / vb) * 100}%` }}>
            <b>{hover.label}</b><div>{hover.kind}{hover.agent.parentName ? ` of ${hover.agent.parentName}` : ""}</div>
            <div className="sub">{hover.agent.envName} • {hover.agent.owner || "no owner"}{hover.agent.autonomous ? " • ⚡ autonomous" : ""}</div>
            <div className="sub">click for details</div>
          </div>
        )}
      </div>
      <div className="maplegend">
        {Object.entries(COLOR).map(([k, c]) => <span key={k}><i style={{ background: c }} />{k}</span>)}
        <span><i style={{ background: "transparent", border: "1.5px solid #ffd166" }} />autonomous</span>
        <span>┄ connected agent</span>
      </div>
    </section>
  );
}
