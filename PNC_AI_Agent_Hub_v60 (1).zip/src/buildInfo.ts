export const BUILD_STAMP = "dev-build";
