export const CSS = `
:root{
  --ink:#0e1726; --panel:#141f33; --panel2:#1b2a45; --line:#26395c;
  --txt:#e8eef9; --dim:#8ca3c7; --cs:#4cc2ff; --ab:#ffb454; --ok:#3ddc84; --bad:#ff6b6b;
}
*{box-sizing:border-box;margin:0}
body{background:var(--ink);color:var(--txt);font:14px/1.45 "Segoe UI",system-ui,sans-serif}
.shell{max-width:1180px;margin:0 auto;padding:28px 22px 60px}
.top{display:flex;justify-content:space-between;align-items:flex-end;gap:16px;border-bottom:1px solid var(--line);padding-bottom:16px;position:relative}
.top::after{content:"";position:absolute;left:0;right:0;bottom:-1px;height:2px;background:linear-gradient(90deg,#4cc2ff,#3ddc84,transparent 70%)}
.brand{display:flex;align-items:center;gap:16px}
.applogo{filter:drop-shadow(0 0 10px rgba(76,194,255,.35))}
.brandlogo{height:34px;margin-left:10px;border-radius:6px;opacity:.92}
.aboutbtn{background:none;border:1px solid var(--line);color:var(--dim);border-radius:6px;padding:1px 9px;font-size:10.5px;cursor:pointer;margin-left:8px}
.aboutbtn:hover{color:var(--txt);border-color:var(--dim)}
.modalwrap{position:fixed;inset:0;background:rgba(6,10,18,.75);backdrop-filter:blur(4px);display:flex;align-items:center;justify-content:center;z-index:50}
.modal{background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:26px 30px;max-width:640px;box-shadow:0 20px 60px rgba(0,0,0,.5)}
.modal h2{margin-bottom:6px}
.aboutlist{margin:14px 0 14px 18px;display:flex;flex-direction:column;gap:8px;font-size:13px;color:var(--dim)}
.aboutlist b{color:var(--txt)}
.eyebrow{font-size:11px;letter-spacing:.18em;color:var(--dim)}
h1{font-size:26px;font-weight:650;letter-spacing:-.01em}
.buildtag{font-size:10.5px;color:#4a5f85;margin-top:3px}
.who{display:flex;align-items:center;gap:10px;background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:8px 14px}
.who-name{font-weight:600}.who-upn{font-size:11.5px;color:var(--dim)}
.signin{background:linear-gradient(90deg,#1d5f8a,#1d8a5f);border:none;color:#fff;font-weight:700;border-radius:9px;padding:10px 22px;font-size:14px;cursor:pointer}
.signin:hover{filter:brightness(1.15)}
.signin-wrap{display:flex;gap:8px;align-items:center}
.dot{width:9px;height:9px;border-radius:50%}.dot.on{background:var(--ok);box-shadow:0 0 8px var(--ok)}.dot.off{background:var(--dim)}
.actions{display:flex;gap:10px;flex-wrap:wrap;margin:20px 0 6px}
.scan{border:1px solid var(--line);background:var(--panel);color:var(--txt);border-radius:10px;padding:12px 18px;font-size:14px;font-weight:600;cursor:pointer;display:flex;gap:10px;align-items:center}
.scan:hover:not(:disabled){background:var(--panel2);transform:translateY(-1px);box-shadow:0 6px 18px rgba(0,0,0,.35)}
.scan{transition:transform .15s ease,box-shadow .15s ease}
.scan:disabled{opacity:.45;cursor:not-allowed}
.scan .k{background:var(--line);border-radius:6px;padding:1px 8px;font-size:12px}
.scan.copilot{border-color:#2d5f80}.scan.builder{border-color:#7a5a2a}.scan.subject{border-color:#4b2d7a}.scan.flows{border-color:#2d7a52}.scan.tree{border-color:#7a2d5f}
.ghost{background:none;border:1px solid var(--bad);color:var(--bad);border-radius:10px;padding:12px 16px;cursor:pointer}
.quicklinks{display:flex;gap:16px;align-items:center;margin:8px 0 0;font-size:12.5px;flex-wrap:wrap}
.quicklinks a{color:var(--cs);text-decoration:none}
.quicklinks a:hover{text-decoration:underline}
.progress{margin:16px 0 4px}
.bar{height:10px;background:var(--panel);border:1px solid var(--line);border-radius:99px;overflow:hidden}
.fill{height:100%;background:linear-gradient(90deg,var(--cs),var(--ok));transition:width .35s ease;box-shadow:0 0 12px rgba(61,220,132,.5)}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.55}}
.bar-meta{margin-top:7px;font-size:12.5px;color:var(--dim)}
.bar-meta b{color:var(--txt)}
.summary{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:18px 0 10px}
.chip{background:var(--panel);border:1px solid var(--line);border-radius:99px;padding:5px 13px;font-size:12.5px;color:var(--dim)}
.chip b{color:var(--txt);margin-right:4px}
.chip.cs b{color:var(--cs)}.chip.ab b{color:var(--ab)}.chip.sa b{color:#c99bff}.chip.m3 b{color:#5fd4c4}
.spacer{flex:1}
.tabs{display:flex;border:1px solid var(--line);border-radius:9px;overflow:hidden;flex-wrap:wrap}
.tab{background:none;border:none;color:var(--dim);padding:6px 13px;cursor:pointer;font-size:12.5px}
.tab.on{background:var(--panel2);color:var(--txt);font-weight:600}
.dl{background:var(--panel2);border:1px solid var(--line);color:var(--txt);border-radius:9px;padding:6px 14px;cursor:pointer;font-weight:600}
.dl:disabled{opacity:.4}
.toolbar{display:flex;gap:10px;align-items:center;margin:2px 0 10px;flex-wrap:wrap}
.envsel,.search{background:var(--panel);border:1px solid var(--line);color:var(--txt);border-radius:9px;padding:8px 12px;font-size:13px}
.search{flex:1;min-width:220px}
.search::placeholder{color:#5f739a}
.clear{background:none;border:1px solid var(--line);color:var(--dim);border-radius:9px;padding:8px 12px;cursor:pointer}
.count{font-size:12px;color:var(--dim);white-space:nowrap}
.srt{cursor:pointer;user-select:none}
.srt:hover{color:var(--txt)}
.grid{border:1px solid var(--line);border-radius:12px;overflow:auto;background:linear-gradient(180deg,var(--panel),#111b2e)}
table{width:100%;border-collapse:collapse;min-width:980px}
th{position:sticky;top:0;background:var(--panel2);text-align:left;font-size:11px;letter-spacing:.08em;color:var(--dim);padding:9px 12px;border-bottom:1px solid var(--line)}
td{padding:9px 12px;border-bottom:1px solid #1c2b47;vertical-align:top}
tr:hover td{background:#182742}
.strong{font-weight:600}
.sub{font-size:11px;color:var(--dim)}.sub2{font-size:11px;color:var(--dim)}
.mono{font-family:Consolas,monospace;font-size:12px}
.pill{border-radius:99px;padding:2px 10px;font-size:11.5px;font-weight:600;white-space:nowrap}
.pill.cs{background:#123a52;color:var(--cs)}.pill.ab{background:#4a3413;color:var(--ab)}.pill.sa{background:#2c1846;color:#c99bff}
.pill.ot{background:#2a2f3a;color:#9fb0c9}.pill.m3{background:#12313a;color:#5fd4c4}.pill.auto{background:#3a2f12;color:#ffd166;margin-left:6px}
.pill.new{background:#0f3d2a;color:#3ddc84;margin-left:8px;font-size:10px;letter-spacing:.08em}
.star{cursor:pointer;color:#3a4c6e;margin-right:8px;font-size:15px;transition:color .15s}
.star:hover{color:#ffd166}.star.on{color:#ffd166;text-shadow:0 0 8px rgba(255,209,102,.5)}
.rowlink{margin-left:8px;color:var(--cs);text-decoration:none;font-weight:700}
.rowlink:hover{text-shadow:0 0 8px rgba(76,194,255,.6)}
.chip-btn{cursor:pointer}.chip-on{cursor:pointer;background:var(--panel2);border-color:#7a5a2a}
.treewrap{display:flex;flex-direction:column;gap:14px}
.treehead{font-size:13px;color:var(--dim);margin-bottom:2px}
.treecard{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:14px 16px}
.treeparent{display:flex;align-items:center;gap:12px}
.treeicon{font-size:20px}.treeicon.small{font-size:15px;color:var(--dim)}
.kidcount{margin-left:auto;background:#123a52;color:var(--cs);border-radius:99px;padding:3px 12px;font-size:11.5px;font-weight:600;white-space:nowrap}
.treekids{margin:10px 0 2px 14px;border-left:2px solid var(--line);padding-left:16px;display:flex;flex-direction:column;gap:9px}
.treekid{display:flex;align-items:center;gap:10px}
.insrow{display:flex;gap:14px;flex-wrap:wrap}
.inscard{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:16px 18px;flex:1;min-width:260px}
.institle{font-size:11.5px;letter-spacing:.12em;color:var(--dim);text-transform:uppercase;margin-bottom:12px}
.legend{font-size:12.5px;color:var(--dim);margin:3px 0}
.legend b{color:var(--txt)}
.dotc{display:inline-block;width:10px;height:10px;border-radius:3px;margin-right:8px}
.grade{font-size:64px;font-weight:800;line-height:1}
.gA{color:#3ddc84}.gB{color:#9fdc3d}.gC{color:#ffd166}.gD{color:#ff9454}.gF{color:#ff6b6b}
.flag{font-size:13px;margin:7px 0;color:var(--dim)}
.flag b{color:var(--txt)}
.envbar{display:flex;align-items:center;gap:10px;margin:7px 0;font-size:12.5px}
.envbarlabel{width:140px;color:var(--dim);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.envbartrack{flex:1;height:12px;background:var(--ink);border-radius:99px;overflow:hidden}
.envbarfill{height:100%;background:linear-gradient(90deg,var(--cs),#3ddc84)}
.treestats{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:4px}
.envgroup{margin-top:6px}
.envhead{font-size:13.5px;font-weight:650;margin:10px 0 8px;color:var(--txt)}
details.treecard>summary{list-style:none;cursor:pointer;display:flex;align-items:center;gap:12px}
details.treecard>summary::-webkit-details-marker{display:none}
details.treecard[open]>summary{margin-bottom:4px}
.xraycard{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:10px 14px;margin:10px 0}
.xraytbl{width:100%;border-collapse:collapse;min-width:0;margin-top:6px}
.xraytbl th{background:none;position:static;font-size:10.5px;padding:4px 8px}
.xraytbl td{padding:5px 8px;border-bottom:1px solid #1c2b47;font-size:12.5px}
.xraytbl tr.xhit td{background:#14301f}
.err{margin:12px 0;background:#3a1620;border:1px solid #6e2434;color:#ffb3bd;border-radius:10px;padding:10px 14px}
.empty{padding:30px;text-align:center;color:var(--dim)}
.skips{margin-top:14px;color:var(--dim);font-size:12.5px}
.skips li{margin:4px 0 4px 18px}
.hint{margin-top:26px;color:var(--dim);max-width:760px;font-size:13px}
@media(max-width:720px){.top{flex-direction:column;align-items:flex-start}}
.drawerwrap{position:fixed;inset:0;background:rgba(6,10,18,.6);z-index:40;display:flex;justify-content:flex-end}
.drawer{width:min(560px,100%);height:100%;overflow:auto;background:var(--panel);border-left:1px solid var(--line);padding:24px 26px;box-shadow:-20px 0 60px rgba(0,0,0,.45)}
.drawer h2{font-size:20px;margin-bottom:4px}
.kv{display:grid;grid-template-columns:140px 1fr;gap:6px 12px;margin:14px 0;font-size:13px}
.kv div:nth-child(odd){color:var(--dim)}
.instr{white-space:pre-wrap;background:var(--ink);border:1px solid var(--line);border-radius:10px;padding:12px;font-size:12.5px;max-height:260px;overflow:auto}
.sect{font-size:11px;letter-spacing:.12em;color:var(--dim);text-transform:uppercase;margin:18px 0 8px}
.qbtn{border-radius:9px;padding:8px 14px;font-weight:700;cursor:pointer;border:1px solid}
.qbtn.on{background:#3a1620;border-color:#6e2434;color:#ffb3bd}
.qbtn.off{background:#10231c;border-color:#2d7a52;color:#9ff0c4}
.qtag{border-radius:99px;padding:2px 10px;font-size:11px;font-weight:700;margin-left:8px}
.qtag.q{background:#3a1620;color:#ff9ecd}
.rowbtn{background:none;border:1px solid var(--line);color:var(--dim);border-radius:7px;padding:2px 8px;font-size:11px;cursor:pointer;margin-left:6px}
.rowbtn:hover{color:var(--txt)}
/* ===== PNC brand accent (orange + navy) ===== */
.shell{--pnc:#F27A21;--pncnavy:#0B2B4C;min-height:100vh;background:var(--ink);color:var(--txt);transition:background .2s,color .2s}
.top::after{background:linear-gradient(90deg,var(--pnc),#ffb066,var(--cs) 80%,transparent)!important}
h1 .pncdot{color:var(--pnc)}
.scan.all{border-color:var(--pnc)!important;background:linear-gradient(90deg,rgba(242,122,33,.18),transparent)}
.tab.on{box-shadow:inset 0 -2px 0 var(--pnc)}
.dl.primary{border-color:var(--pnc);color:var(--pnc)}
.pnclogo{height:38px;margin-left:12px;border-radius:6px}
.themebtn{background:var(--panel2);border:1px solid var(--line);color:var(--txt);border-radius:99px;padding:6px 12px;cursor:pointer;font-size:12.5px;margin-right:10px}
.headright{display:flex;align-items:center;gap:8px}
/* ===== footer ===== */
.footer{margin-top:48px;padding-top:18px;border-top:1px solid var(--line);display:flex;align-items:center;justify-content:center;gap:10px;color:var(--dim);font-size:13.5px;letter-spacing:.02em}
.footer b{color:var(--pnc)}
/* ===== email modal ===== */
.field{display:flex;flex-direction:column;gap:5px;margin:10px 0;font-size:12.5px;color:var(--dim)}
.field input{background:var(--ink);border:1px solid var(--line);color:var(--txt);border-radius:8px;padding:8px 10px;font-size:13px}
.checks{display:flex;gap:16px;margin:8px 0 4px;font-size:13px}
/* ===== LIGHT MODE ===== */
.shell[data-theme="light"]{--ink:#f4f6fa;--panel:#ffffff;--panel2:#eef2f8;--line:#d6dde9;--txt:#14213d;--dim:#5a6a84;--cs:#0067b1;--ab:#b35c00;--ok:#14864a;--bad:#c62828}
.shell[data-theme="light"] .grid{background:#fff}
.shell[data-theme="light"] th{background:#eef2f8}
.shell[data-theme="light"] td{border-bottom-color:#e8edf4}
.shell[data-theme="light"] tr:hover td{background:#f5f8fc}
.shell[data-theme="light"] .pill.cs{background:#dcecfa;color:#0067b1}
.shell[data-theme="light"] .pill.ab{background:#fdebd8;color:#a8550a}
.shell[data-theme="light"] .pill.sa{background:#efe3fb;color:#6b2fb3}
.shell[data-theme="light"] .pill.ot{background:#e9edf3;color:#46556d}
.shell[data-theme="light"] .pill.m3{background:#daf3ef;color:#0b7a6b}
.shell[data-theme="light"] .pill.auto{background:#fff3cd;color:#8a6200}
.shell[data-theme="light"] .kidcount{background:#dcecfa;color:#0067b1}
.shell[data-theme="light"] .err{background:#fde8ea;border-color:#f3b4bc;color:#9b1c2c}
.shell[data-theme="light"] .instr,.shell[data-theme="light"] .field input{background:#f7f9fc}
.shell[data-theme="light"] .buildtag{color:#7a8aa3}
.shell[data-theme="light"] .modalwrap,.shell[data-theme="light"] .drawerwrap{background:rgba(20,33,61,.35)}
.shell[data-theme="light"] .envbartrack{background:#e8edf4}
/* ===== landing hero ===== */
.hero{display:flex;flex-direction:column;align-items:center;text-align:center;padding:46px 10px 10px}
.hublogo{filter:drop-shadow(0 10px 30px rgba(242,122,33,.35))}
.hubspin{transform-origin:100px 100px;animation:hubspin 28s linear infinite}
@keyframes hubspin{to{transform:rotate(360deg)}}
.herotitle{font-size:40px;font-weight:800;letter-spacing:-.02em;margin-top:18px}
.herotitle span{background:linear-gradient(90deg,#F27A21,#ffb066);-webkit-background-clip:text;background-clip:text;color:transparent}
.herosub{color:var(--dim);font-size:15px;max-width:620px;margin-top:8px}
.herobtn{margin-top:22px;font-size:16px;padding:14px 26px}
@media (prefers-reduced-motion: reduce){.hubspin{animation:none}}
/* ===== agent map ===== */
.mapcanvas{position:relative;background:var(--panel);border:1px solid var(--line);border-radius:14px;overflow:hidden}
.maplabel{fill:var(--txt);font-size:15px;font-weight:600}
.mapnode circle{transition:r .15s}
.mapnode:hover circle{filter:brightness(1.3)}
.pulse{animation:pulse 2s ease-in-out infinite;transform-box:fill-box;transform-origin:center}
@keyframes pulse{0%,100%{opacity:.9}50%{opacity:.2}}
.maptip{position:absolute;transform:translate(12px,12px);background:var(--panel2);border:1px solid var(--line);border-radius:10px;padding:8px 12px;font-size:12.5px;pointer-events:none;max-width:260px;box-shadow:0 8px 24px rgba(0,0,0,.35);z-index:5}
.maplegend{display:flex;gap:16px;flex-wrap:wrap;margin-top:10px;font-size:12px;color:var(--dim)}
.maplegend i{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:6px;vertical-align:-1px}
/* ===== people picker / env search ===== */
.pp,.envfind{position:relative}
.envfind{flex:1;min-width:260px;max-width:460px;display:flex;align-items:center}
.envfind .search{width:100%}
.envx{position:absolute;right:8px;background:none;border:0;color:var(--dim);font-size:18px;cursor:pointer}
.ppbox{display:flex;flex-wrap:wrap;gap:6px;align-items:center;background:var(--panel2);border:1px solid var(--line);border-radius:10px;padding:6px 8px;min-height:40px;margin-top:4px}
.ppbox input{flex:1;min-width:160px;background:transparent!important;border:0!important;outline:none;color:var(--txt);font-size:14px;padding:4px!important;margin:0!important}
.ppchip{display:inline-flex;align-items:center;gap:6px;background:rgba(242,122,33,.16);color:var(--txt);border:1px solid rgba(242,122,33,.45);border-radius:999px;padding:3px 4px 3px 10px;font-size:12.5px}
.ppchip button{background:none;border:0;color:var(--dim);cursor:pointer;font-size:15px;line-height:1}
.ppspin{font-size:13px}
.ppmenu{position:absolute;left:0;right:0;top:calc(100% + 4px);background:var(--panel2);border:1px solid var(--line);border-radius:12px;box-shadow:0 14px 34px rgba(0,0,0,.35);z-index:50;max-height:320px;overflow:auto;padding:4px;text-align:left}
.ppitem{display:flex;gap:10px;align-items:center;padding:8px 10px;border-radius:9px;cursor:pointer}
.ppitem:hover,.ppitem.on{background:rgba(242,122,33,.14)}
.ppav{flex:none;width:30px;height:30px;border-radius:50%;display:grid;place-items:center;background:linear-gradient(135deg,#F27A21,#0B2B4C);color:#fff;font-size:11.5px;font-weight:700}
.ownerbar{align-items:center}
.ownergrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:8px;margin-top:8px}
.ownerchip{display:flex;gap:10px;align-items:center;text-align:left;background:var(--panel2);border:1px solid var(--line);border-radius:12px;padding:8px 10px;color:var(--txt);cursor:pointer}
.ownerchip:hover{border-color:#F27A21}
.ownerlink{cursor:pointer;border-bottom:1px dotted var(--dim)}
.ownerlink:hover{color:#F27A21}
.consolelinks{display:flex;flex-direction:column;gap:8px}
.consolelinks a{text-decoration:none}
/* ===== agents to watch ===== */
.risk{display:inline-block;margin-left:6px;padding:2px 8px;border-radius:999px;font-size:11px;font-weight:700}
.risk.High,.riskc.High b{background:rgba(255,77,94,.18);color:#ff6b7a}
.risk.Medium,.riskc.Medium b{background:rgba(255,180,84,.18);color:#ffb454}
.risk.Low,.riskc.Low b{background:rgba(95,212,196,.16);color:#5fd4c4}
.riskc b{padding:0 6px;border-radius:6px}
.watchrow{display:flex;align-items:center;gap:14px;background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:12px 16px;margin-bottom:10px;cursor:pointer;transition:transform .12s,border-color .12s}
.watchrow:hover{transform:translateY(-1px);border-color:#F27A21}
.rank{font-weight:800;color:var(--dim);width:34px}
.gauge{--c:#5fd4c4;flex:none;width:54px;height:54px;border-radius:50%;display:grid;place-items:center;background:conic-gradient(var(--c) calc(var(--p)*1%),rgba(128,140,160,.18) 0)}
.gauge.High{--c:#ff4d5e}.gauge.Medium{--c:#ffb454}
.gauge span{width:42px;height:42px;border-radius:50%;background:var(--panel);display:grid;place-items:center;font-weight:800;font-size:15px}
.reasons{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px}
.reason{font-size:11.5px;background:var(--panel2);border:1px solid var(--line);border-radius:999px;padding:2px 8px;color:var(--dim)}
.scorebar{width:140px;height:8px;border-radius:99px;background:rgba(128,140,160,.18);overflow:hidden}
.scorefill{height:100%;border-radius:99px;background:#5fd4c4}
.scorefill.High{background:linear-gradient(90deg,#ffb454,#ff4d5e)}.scorefill.Medium{background:linear-gradient(90deg,#5fd4c4,#ffb454)}
@media (max-width:700px){.scorebar{display:none}}
/* ===== lifecycle ===== */
.lifechips{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px}
.lifechip{display:flex;gap:6px;align-items:center;background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:8px 12px;color:var(--txt);cursor:pointer;font-size:13px}
.lifechip.on{border-color:#F27A21;box-shadow:0 0 0 2px rgba(242,122,33,.25)}
.lifetag{font-size:12px;padding:2px 8px;border-radius:999px;background:var(--panel2);white-space:nowrap}
.lifetag.L0{background:rgba(255,77,94,.18);color:#ff6b7a}.lifetag.L1{background:rgba(159,176,201,.2)}
.lifetag.L2{background:rgba(201,155,255,.18);color:#c99bff}.lifetag.L3{background:rgba(255,180,84,.18);color:#ffb454}
.lifetag.L4{background:rgba(76,194,255,.16);color:#4cc2ff}.lifetag.L5{background:rgba(95,212,196,.16);color:#5fd4c4}
.glabel{fill:var(--dim);font-size:11px}
.recertscopes{display:flex;flex-wrap:wrap;gap:8px;margin:12px 0}
.recertlist{max-height:260px;overflow:auto;border:1px solid var(--line);border-radius:12px;padding:4px;background:var(--panel)}
/* ===== capability graph ===== */
.capwrap{background:var(--panel2);border:1px solid var(--line);border-radius:14px;padding:12px;margin-top:4px}
.capchips{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:6px}
.capchip{display:inline-flex;gap:5px;align-items:center;font-size:12px;border:1px solid;border-radius:999px;padding:2px 9px;background:var(--panel)}
.capsvg{display:block;max-height:340px;overflow:visible}
.caplabel{fill:var(--txt);font-size:11px}
.capnode{cursor:default}
.capnode:hover circle{fill-opacity:.4}
.capflow{stroke-dasharray:4 4;animation:capflow 1.6s linear infinite}
@keyframes capflow{to{stroke-dashoffset:-16}}
.capcore{filter:drop-shadow(0 0 10px rgba(242,122,33,.55))}
.captip{position:absolute;left:8px;bottom:8px;max-width:80%;background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:6px 10px;font-size:12px;box-shadow:0 8px 20px rgba(0,0,0,.3)}
.capsub{font-size:12px;font-weight:700;color:var(--dim);margin:8px 0 6px;text-transform:uppercase;letter-spacing:.04em}
.capbar{display:grid;grid-template-columns:170px 1fr minmax(90px,auto);gap:8px;align-items:center;font-size:12.5px;margin-bottom:5px}
.capbarname{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.capbartrack{height:8px;border-radius:99px;background:rgba(128,140,160,.18);overflow:hidden}
.capbarfill{height:100%;border-radius:99px}
.capbarops{color:var(--dim);font-size:11.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:200px}
@media (prefers-reduced-motion: reduce){.capflow{animation:none}}
/* ===== id finder / atlas / sprawl ===== */
.idbtn{align-self:center}
.idcard{background:var(--panel2);border:1px solid var(--line);border-left:4px solid #F27A21;border-radius:14px;padding:12px 14px;margin-top:12px}
.idrole{display:flex;gap:12px;align-items:center;margin-bottom:8px}
.idicon{font-size:30px;width:46px;height:46px;display:grid;place-items:center;border-radius:12px;background:var(--panel)}
.idrolename{font-size:16px;font-weight:800}
.atlasrow{background:var(--panel);border:1px solid var(--line);border-radius:12px;margin-bottom:8px;overflow:hidden}
.atlashead{display:grid;grid-template-columns:90px minmax(180px,1.4fr) 110px 1fr 40px 20px;gap:10px;align-items:center;padding:10px 14px;cursor:pointer}
.atlashead:hover{background:rgba(242,122,33,.06)}
.atlasname{display:flex;gap:8px;align-items:center;min-width:0}
.atlasn{text-align:right}
.tierpill{border:1px solid;border-radius:999px;padding:2px 10px;font-size:11.5px;font-weight:700;text-align:center}
.tierdot{display:inline-block;width:9px;height:9px;border-radius:50%}
.unblk{font-size:10.5px;color:var(--dim);border:1px dashed var(--line);border-radius:999px;padding:1px 7px;white-space:nowrap}
.atlasbody{padding:4px 14px 12px;border-top:1px solid var(--line)}
@media (max-width:760px){.atlashead{grid-template-columns:70px 1fr 40px 20px}.atlaskind,.atlashead .capbartrack{display:none}}
`;
