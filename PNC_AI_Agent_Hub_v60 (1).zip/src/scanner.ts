/* ------------------------------------------------------------------------
   Scan engine — tenant-wide, connector-only.
   Detection rules (tenant-verified, see ZERO-TO-HERO.md):
   • Copilot Studio agent  = bots row with a Custom GPT (15) component
   • Agent Builder (lite)  = inventory createdIn says lite/M365, or
                             bots.template starts with "gpt" (Kit rule)
   • Classic (V1)          = bot has V1 components (types 0–8) and NO V2
                             components (9–20) — Microsoft Learn option set;
                             a missing Custom GPT (15) does NOT mean classic
   • Child agent           = botcomponent Topic V2 (9) under the parent whose
                             data contains "kind: AgentDialog"
   • Connected agent link  = parent topic data invoking another bot's
                             schema name (InvokeConnectedAgent…)
   • Autonomous            = External Trigger (17) component present
------------------------------------------------------------------------ */
import { extractCaps, Cap } from "./capabilities";
import { listEnvironments, listRows, hasInventory, queryInventory, Env } from "./connectors";

export type Kind = "Copilot Studio" | "Agent Builder" | "Child Agent" | "Classic (V1)" | "Flow";
export type Details = {
  instructions: string; knowledge: number; tools: string[]; triggers: number;
  children: string[]; connected: string[]; components: number;
  caps?: Cap[]; skills?: string[]; knowledgeNames?: string[];
};
export type LinkRef = { label: string; url: string };
export type Agent = {
  id: string; name: string; kind: Kind; envId: string; envName: string; envUrl: string;
  owner: string; ownerEmail: string; link: string; linkLabel: string; createdOn: string; modifiedOn: string; publishedOn: string; state: string;
  schema: string; authMode: string; autonomous: boolean; template: string;
  parentId: string; parentName: string; relation: "" | "Child" | "Connected";
  details?: Details;
  links?: LinkRef[]; orchestration?: string; entraAgentId?: string; quarantined?: boolean; ownerDisabled?: boolean; isDefaultEnv?: boolean; access?: string; status?: string; source?: string;
};
export type Progress = (msg: string, done: number, total: number) => void;
export type ScanResult = { agents: Agent[]; envs: Env[]; skipped: string[]; notes: string[] };

const F = "@OData.Community.Display.V1.FormattedValue";
const BOT_SELECT_FULL = "name,botid,schemaname,createdon,modifiedon,publishedon,statecode,statuscode,accesscontrolpolicy,template,authenticationmode,configuration,_ownerid_value,_owninguser_value";
const BOT_SELECT = "name,botid,schemaname,createdon,modifiedon,publishedon,statecode,template,authenticationmode,_ownerid_value,_owninguser_value";
const BOT_SELECT_MIN = "name,botid,schemaname,createdon,modifiedon,statecode,_ownerid_value,_owninguser_value";
const COMP_SELECT = "name,botcomponentid,componenttype,_parentbotid_value,schemaname,createdon,modifiedon,data";
const COMP_FILTER = "componenttype eq 1 or componenttype eq 13 or componenttype eq 9 or componenttype eq 14 or componenttype eq 15 or componenttype eq 16 or componenttype eq 17";

const LITE = /lite|agentbuilder|agent builder|m365|microsoft365|bizchat|declarative/i;

function instructionsOf(yaml: string): string {
  const m = yaml.match(/(?:^|\n)\s*instructions:\s*(\|[-+]?|>[-+]?)?\s*\n?([\s\S]*?)(?=\n[A-Za-z_]+:|\s*$)/);
  if (!m) return "";
  return m[2].split("\n").map(l => l.replace(/^\s{2,}/, "")).join("\n").trim().slice(0, 4000);
}

const GUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
type User = { name: string; email: string; disabled: boolean };
/** Resolve owner display name + email from the environment's systemusers table. */
async function lookupUsers(url: string, ids: string[], byAad = false): Promise<Map<string, User>> {
  const out = new Map<string, User>();
  const uniq = [...new Set(ids.filter(i => GUID.test(i)).map(i => i.toLowerCase()))];
  const col = byAad ? "azureactivedirectoryobjectid" : "systemuserid";
  for (let i = 0; i < uniq.length; i += 40) {
    const chunk = uniq.slice(i, i + 40);
    try {
      const rows = await listRows(url, "systemusers", {
        select: "systemuserid,fullname,internalemailaddress,domainname,azureactivedirectoryobjectid,isdisabled",
        filter: chunk.map(id => `${col} eq ${id}`).join(" or ")
      });
      rows.forEach(u => out.set(String(u[col]).toLowerCase(), {
        name: u.fullname ?? "", email: u.internalemailaddress || u.domainname || "", disabled: u.isdisabled === true
      }));
    } catch { /* table not readable — keep formatted owner name */ }
  }
  return out;
}

/* Verified deep links (researched Oct 2026):
   Copilot Studio agent  https://copilotstudio.microsoft.com/environments/{envId}/bots/{botId}   (Microsoft Learn "agent URL")
   Agent Builder agent   HIDDEN from Copilot Studio by design (Microsoft Q&A) and no per-agent URL is
                         documented → Microsoft 365 admin center ▸ Agents ▸ All agents (registry,
                         Platform = "Agent Builder"), backup: PPAC ▸ Manage ▸ Copilot Studio inventory
   Child agent           lives INSIDE its parent → parent agent's Copilot Studio page
   Connected agent       separate bot → its own Copilot Studio page
   Flow                  https://make.powerautomate.com/environments/{envId}/flows/{flowId}/details */
export const csLink = (envId: string, botId: string) =>
  `https://copilotstudio.microsoft.com/environments/${envId}/bots/${botId}`;
export const M365_AGENTS = "https://admin.microsoft.com/#/agents/all";
export const PPAC_AGENTS = "https://admin.powerplatform.microsoft.com/manage/resources/copilotstudio";
export const PPAC_INVENTORY = "https://admin.powerplatform.microsoft.com/manage/inventory";
const L = (label: string, url: string): LinkRef => ({ label, url });
export function linksFor(kind: Kind, envId: string, botId: string, parentName = ""): LinkRef[] {
  if (kind === "Agent Builder") return [
    L("Microsoft 365 admin center ▸ Agents (Agent Builder registry)", M365_AGENTS),
    L("Power Platform admin center ▸ Copilot Studio agents", PPAC_AGENTS),
    L("Copilot Studio (admins only — Agent Builder agents are usually hidden)", csLink(envId, botId))];
  if (kind === "Child Agent") return [
    L(`Copilot Studio ▸ parent "${parentName}" ▸ Agents`, csLink(envId, botId)),
    L("Power Platform admin center ▸ Copilot Studio agents", PPAC_AGENTS)];
  return [L("Copilot Studio", csLink(envId, botId)), L("Power Platform admin center ▸ Copilot Studio agents", PPAC_AGENTS)];
}

async function pool<T>(items: T[], n: number, fn: (t: T, i: number) => Promise<void>) {
  let i = 0;
  await Promise.all(Array.from({ length: Math.min(n, items.length) }, async () => {
    while (i < items.length) { const k = i++; await fn(items[k], k); }
  }));
}

export async function scanTenant(progress: Progress, cancelled: () => boolean, onlyEnv?: (e: Env) => boolean): Promise<ScanResult> {
  const notes: string[] = [];
  const skipped: string[] = [];
  progress("Listing environments (Power Platform for Admins)…", 0, 1);
  const allEnvs = await listEnvironments();
  const envs = onlyEnv ? allEnvs.filter(onlyEnv) : allEnvs;
  if (onlyEnv) notes.push(`Scoped scan: ${envs.length} of ${allEnvs.length} environments`);
  const envIds = new Set(envs.map(e => e.id.toLowerCase()));
  const withDv = envs.filter(e => e.url);
  envs.filter(e => !e.url).forEach(e => skipped.push(`${e.name} — no Dataverse, agents not possible`));

  /* ---- optional authoritative inventory (Admins V2) ---- */
  const inv = new Map<string, any>();
  const flows: Agent[] = [];
  if (hasInventory()) {
    try {
      progress("Querying Power Platform inventory…", 0, withDv.length);
      const recs = await queryInventory();
      const envName = new Map(envs.map(e => [e.id.toLowerCase(), e.name]));
      recs.forEach((r: any) => {
        const p = r.properties ?? {};
        const t = String(r.type ?? "").toLowerCase();
        if (t.endsWith("/agents")) inv.set(String(r.name).toLowerCase(), { ...p, _name: r.name });
        else if (t.includes("flow") && (!onlyEnv || envIds.has(String(p.environmentId ?? "").toLowerCase()))) flows.push({
          id: r.name, name: p.displayName ?? p.flowDisplayName ?? r.name, kind: "Flow",
          envId: p.environmentId ?? "", envName: envName.get(String(p.environmentId ?? "").toLowerCase()) ?? p.environmentId ?? "",
          envUrl: "", owner: p.createdBy ?? p.owner ?? "", ownerEmail: "",
          link: p.environmentId ? `https://make.powerautomate.com/environments/${p.environmentId}/flows/${r.name}/details` : "",
          linkLabel: "Open in Power Automate", links: p.environmentId ? [
            L("Power Automate ▸ flow details", `https://make.powerautomate.com/environments/${p.environmentId}/flows/${r.name}/details`),
            L("Power Platform admin center ▸ Inventory", PPAC_INVENTORY)] : [], createdOn: p.createdAt ?? p.createdTime ?? "",
          modifiedOn: p.lastModifiedTime ?? "", publishedOn: "", state: p.state ?? "", schema: r.type ?? "",
          authMode: "", autonomous: false, template: "", parentId: "", parentName: "", relation: ""
        });
      });
      notes.push(`Inventory: ${inv.size} agents, ${flows.length} flows tenant-wide`);
    } catch (e: any) {
      notes.push(`Inventory unavailable (${e?.message ?? e}) — Dataverse signals used instead`);
    }
  } else notes.push("Inventory connector not added — Dataverse signals used for Agent Builder detection");

  /* ---- per environment: bots + components ---- */
  const agents: Agent[] = [];
  let done = 0;
  await pool(withDv, 3, async env => {
    if (cancelled()) return;
    progress(`Scanning ${env.name}`, done, withDv.length);
    try {
      let bots: any[];
      try { bots = await listRows(env.url!, "bots", { select: BOT_SELECT_FULL }); }
      catch {
        try { bots = await listRows(env.url!, "bots", { select: BOT_SELECT }); }
        catch { bots = await listRows(env.url!, "bots", { select: BOT_SELECT_MIN }); }
      }
      // lightweight type map of EVERY component → V1 vs V2 classification
      const v1 = new Set<string>(), v2 = new Set<string>();
      let typed = false;
      try {
        const all = await listRows(env.url!, "botcomponents", { select: "_parentbotid_value,componenttype" }, 50000);
        all.forEach(c => { const k = String(c._parentbotid_value ?? "").toLowerCase(); (c.componenttype <= 8 ? v1 : v2).add(k); });
        typed = true;
      } catch { /* fall back to rich query below */ }
      let comps: any[] = [];
      try { comps = await listRows(env.url!, "botcomponents", { select: COMP_SELECT, filter: COMP_FILTER }); }
      catch (e: any) { skipped.push(`${env.name} (components) — ${e?.message ?? e}`); }

      const users = await lookupUsers(env.url!, bots.map(b => String(b._owninguser_value ?? "")));
      const ownerOf = (b: any) => {
        const u = users.get(String(b._owninguser_value ?? "").toLowerCase());
        return { owner: u?.name || (b[`_ownerid_value${F}`] ?? ""), ownerEmail: u?.email ?? "", ownerDisabled: !!u?.disabled };
      };
      const byParent = new Map<string, any[]>();
      comps.forEach(c => {
        const k = String(c._parentbotid_value ?? "").toLowerCase();
        if (!byParent.has(k)) byParent.set(k, []);
        byParent.get(k)!.push(c);
      });
      const bySchema = new Map(bots.map(b => [String(b.schemaname ?? "").toLowerCase(), b]));

      bots.forEach(b => {
        const id = String(b.botid).toLowerCase();
        const mine = byParent.get(id) ?? [];
        const gpt = mine.find(c => c.componenttype === 15);
        const children: string[] = [], connected: string[] = [], tools: string[] = [];
        let triggers = 0, knowledge = 0;
        const capBag = new Map<string, Cap>(); const skills: string[] = [], knowledgeNames: string[] = [];
        mine.forEach(c => {
          const d = String(c.data ?? "");
          if (c.componenttype === 17) triggers++;
          if (c.componenttype === 14 || c.componenttype === 16) { knowledge++; if (c.name) knowledgeNames.push(c.name); }
          if (c.componenttype === 1 || c.componenttype === 13) { skills.push(c.name ?? "(skill)"); return; }
          if (c.componenttype === 9 || c.componenttype === 17) extractCaps(d, c.name ?? "", capBag);
          if (c.componenttype !== 9) return;
          if (/kind:\s*AgentDialog/i.test(d)) {
            children.push(c.name);
            agents.push({
              id: c.botcomponentid, name: c.name ?? "(unnamed)", kind: "Child Agent",
              envId: env.id, envName: env.name, envUrl: env.url!, ...ownerOf(b),
              link: csLink(env.id, b.botid), linkLabel: `Open parent "${b.name}" → Agents`,
              links: linksFor("Child Agent", env.id, b.botid, b.name ?? ""), isDefaultEnv: env.isDefault,
              createdOn: c.createdon ?? "", modifiedOn: c.modifiedon ?? "", publishedOn: "", state: "",
              schema: c.schemaname ?? "", authMode: "", autonomous: false, template: "",
              parentId: b.botid, parentName: b.name ?? "", relation: "Child"
            });
          } else if (/InvokeConnectedAgent|ConnectedAgent/i.test(d)) {
            const sm = d.match(/botSchemaName:\s*([\w.\-]+)/i);
            const target = sm ? bySchema.get(sm[1].toLowerCase()) : null;
            if (target) connected.push(target.name);
          } else if (/kind:\s*TaskDialog|InvokeConnectorTaskAction|InvokeFlowTaskAction|InvokeExternalAgentTaskAction|InvokeAIBuilderModelTaskAction|InvokeComputerUsingAgentTaskAction|InvokeAIPluginTaskAction/i.test(d)) {
            tools.push(c.name);
          }
        });
        const p = inv.get(id);
        if (p) p._seen = true;
        const createdIn = String(p?.createdIn ?? "");
        const template = String(b.template ?? "");
        const hasV2 = v2.has(id) || mine.length > 0;
        const hasV1 = v1.has(id);
        const kind: Kind =
          (createdIn && LITE.test(createdIn)) || /^gpt/i.test(template) || /microsoft 365 copilot chat/i.test(env.name) ? "Agent Builder" :
          /^cliagent|^default-2/i.test(template) || hasV2 ? "Copilot Studio" :
          typed && hasV1 ? "Classic (V1)" : "Copilot Studio";
        agents.push({
          id: b.botid, name: b.name ?? "(unnamed)", kind, envId: env.id, envName: env.name, envUrl: env.url!,
          ...ownerOf(b), link: kind === "Agent Builder" ? M365_AGENTS : csLink(env.id, b.botid),
          linkLabel: kind === "Agent Builder" ? "Open in Microsoft 365 admin center ▸ Agents" : "Open in Copilot Studio",
          links: linksFor(kind, env.id, b.botid), isDefaultEnv: env.isDefault,
          access: b[`accesscontrolpolicy${F}`] ?? "", status: b[`statuscode${F}`] ?? "", source: createdIn || "Dataverse",
          orchestration: b.configuration ? (/"GenerativeActionsEnabled"\s*:\s*true/i.test(String(b.configuration)) ? "Generative" : "Classic") : (p?.orchestration ?? ""),
          entraAgentId: p?.entraAgentId ?? p?.entraAppId ?? "", quarantined: p?.isQuarantined === true ? true : undefined,
          createdOn: b.createdon ?? "", modifiedOn: b.modifiedon ?? "",
          publishedOn: b.publishedon ?? "", state: b[`statecode${F}`] ?? String(b.statecode ?? ""),
          schema: b.schemaname ?? "", authMode: b[`authenticationmode${F}`] ?? "", autonomous: triggers > 0,
          template, parentId: "", parentName: "", relation: "",
          details: {
            instructions: gpt ? instructionsOf(String(gpt.data ?? "")) : "", knowledge, tools, triggers,
            children, connected, components: mine.length,
            caps: [...capBag.values()].sort((x, y) => y.uses - x.uses), skills, knowledgeNames
          }
        });
        // connected-agent links: record on the target too so the tree can show them
        connected.forEach(t => {
          const tb = bots.find(x => x.name === t);
          if (tb) agents.push({
            id: `${tb.botid}|via|${b.botid}`, name: tb.name, kind: "Child Agent", envId: env.id, envName: env.name,
            envUrl: env.url!, ...ownerOf(tb), link: csLink(env.id, tb.botid), linkLabel: "Open connected agent in Copilot Studio",
            links: linksFor("Copilot Studio", env.id, tb.botid),
            createdOn: tb.createdon ?? "",
            modifiedOn: tb.modifiedon ?? "", publishedOn: tb.publishedon ?? "", state: "", schema: tb.schemaname ?? "",
            authMode: "", autonomous: false, template: "", parentId: b.botid, parentName: b.name ?? "", relation: "Connected"
          });
        });
      });
    } catch (e: any) {
      skipped.push(`${env.name} — ${e?.message ?? e}`);
    }
    done++;
    progress(`Scanned ${env.name}`, done, withDv.length);
  });

  /* ---- Agent Builder agents known to the inventory but not readable in Dataverse ---- */
  const envById = new Map(envs.map(e => [e.id.toLowerCase(), e]));
  inv.forEach((p: any, id: string) => {
    if (p._seen || !LITE.test(String(p.createdIn ?? ""))) return;
    const eid = String(p.environmentId ?? "").toLowerCase();
    if (onlyEnv && !envIds.has(eid)) return;
    const env = envById.get(eid);
    agents.push({
      id: p._name ?? id, name: p.displayName ?? p.name ?? p.schemaName ?? id, kind: "Agent Builder",
      envId: p.environmentId ?? "", envName: env?.name ?? p.environmentId ?? "", envUrl: env?.url ?? "",
      owner: p.ownerName ?? p.createdByDisplayName ?? p.createdBy ?? p.ownerId ?? "", ownerEmail: p.ownerEmail ?? p.createdByEmail ?? "",
      link: M365_AGENTS, linkLabel: "Open in Microsoft 365 admin center ▸ Agents",
      links: linksFor("Agent Builder", p.environmentId ?? "", p._name ?? id), isDefaultEnv: env?.isDefault,
      createdOn: p.createdAt ?? p.createdOn ?? "", modifiedOn: p.lastModifiedAt ?? p.modifiedOn ?? "", publishedOn: p.publishedOn ?? "",
      state: p.state ?? p.status ?? "", schema: p.schemaName ?? "", authMode: "", autonomous: false, template: "",
      parentId: "", parentName: "", relation: "", source: "Inventory only"
    });
  });
  // inventory owners are often AAD object ids → resolve where possible
  const invOnly = agents.filter(a => a.source === "Inventory only" && GUID.test(a.owner) && a.envUrl);
  await pool([...new Set(invOnly.map(a => a.envUrl))], 3, async url => {
    const list = invOnly.filter(a => a.envUrl === url);
    const m = await lookupUsers(url, list.map(a => a.owner), true);
    list.forEach(a => { const u = m.get(a.owner.toLowerCase()); if (u) { a.owner = u.name; a.ownerEmail = u.email; a.ownerDisabled = u.disabled; } });
  });

  const urlOf = new Map(withDv.map(e => [e.id.toLowerCase(), e.url!]));
  const flowsByEnv = new Map<string, Agent[]>();
  flows.forEach(f => { const k = f.envId.toLowerCase(); if (!flowsByEnv.has(k)) flowsByEnv.set(k, []); flowsByEnv.get(k)!.push(f); });
  await pool([...flowsByEnv.entries()], 3, async ([envId, fl]) => {
    const url = urlOf.get(envId);
    if (!url) return;
    const m = await lookupUsers(url, fl.map(f => f.owner), true);
    fl.forEach(f => { const u = m.get(f.owner.toLowerCase()); if (u) { f.owner = u.name; f.ownerEmail = u.email; f.ownerDisabled = u.disabled; } });
  });

  flows.forEach(f => { const e = envById.get(f.envId.toLowerCase()); f.isDefaultEnv = e?.isDefault; });
  return { agents: [...agents, ...flows], envs, skipped, notes };
}

/* ---------------- 🆔 live lookup of ANY agent id across environments -----------------
   Accepts a bot id, a botcomponent id (child agent / topic), a schema name, or a
   Copilot Studio / Power Automate URL. Searches every Dataverse environment. */
export const extractId = (raw: string) => {
  const s = raw.trim();
  const g = s.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi);
  if (g?.length) { const bot = s.match(/bots\/([0-9a-f-]{36})/i); const flow = s.match(/flows\/([0-9a-f-]{36})/i); return (bot?.[1] ?? flow?.[1] ?? g[g.length - 1]).toLowerCase(); }
  return s.replace(/['"\s]/g, "");
};
export type LookupHit = { agent: Agent; how: string };
export async function lookupById(envs: Env[], raw: string, progress?: (m: string) => void): Promise<LookupHit[]> {
  const id = extractId(raw); const isGuid = GUID.test(id); const hits: LookupHit[] = [];
  const base = (env: Env, b: any): Agent => ({
    id: b.botid, name: b.name ?? "(unnamed)", kind: /^gpt/i.test(b.template ?? "") ? "Agent Builder" : "Copilot Studio",
    envId: env.id, envName: env.name, envUrl: env.url!, owner: b[`_ownerid_value${F}`] ?? "", ownerEmail: "",
    link: csLink(env.id, b.botid), linkLabel: "Open in Copilot Studio", links: linksFor(/^gpt/i.test(b.template ?? "") ? "Agent Builder" : "Copilot Studio", env.id, b.botid),
    createdOn: b.createdon ?? "", modifiedOn: b.modifiedon ?? "", publishedOn: b.publishedon ?? "", state: b[`statecode${F}`] ?? "",
    schema: b.schemaname ?? "", authMode: "", autonomous: false, template: b.template ?? "", parentId: "", parentName: "", relation: "", source: "Live ID lookup"
  });
  await pool(envs.filter(e => e.url), 4, async env => {
    progress?.(`Looking in ${env.name}…`);
    const esc = id.replace(/'/g, "''");
    try {
      const bots = await listRows(env.url!, "bots", { select: "name,botid,schemaname,createdon,modifiedon,publishedon,statecode,template,_ownerid_value",
        filter: isGuid ? `botid eq ${id}` : `schemaname eq '${esc}' or name eq '${esc}'` }, 5);
      bots.forEach(b => hits.push({ agent: base(env, b), how: isGuid ? "bot id" : "schema name / name" }));
      const comps = await listRows(env.url!, "botcomponents", { select: "name,botcomponentid,componenttype,schemaname,createdon,modifiedon,_parentbotid_value,data",
        filter: isGuid ? `botcomponentid eq ${id}` : `schemaname eq '${esc}'` }, 5);
      for (const c of comps) {
        const pb = (await listRows(env.url!, "bots", { select: "name,botid,schemaname,template,_ownerid_value", filter: `botid eq ${c._parentbotid_value}` }, 1))[0];
        const child = /kind:\s*AgentDialog/i.test(String(c.data ?? "")) || c.componenttype === 15;
        hits.push({ how: isGuid ? "component id" : "component schema name", agent: {
          ...base(env, pb ?? { botid: c._parentbotid_value }), id: c.botcomponentid, name: c.name ?? "(component)",
          kind: child ? "Child Agent" : "Copilot Studio", schema: c.schemaname ?? "", createdOn: c.createdon ?? "", modifiedOn: c.modifiedon ?? "",
          parentId: c._parentbotid_value, parentName: pb?.name ?? "", relation: child ? "Child" : "",
          linkLabel: `Open parent "${pb?.name ?? ""}"`, links: linksFor("Child Agent", env.id, c._parentbotid_value, pb?.name ?? ""),
          state: child ? "child agent" : `component type ${c.componenttype}`
        } });
      }
    } catch { /* env not readable */ }
  });
  return hits;
}
