/* ------------------------------------------------------------------------
   Connector layer — NO app registration, NO MSAL.
   Every call goes through the Power Apps host using the signed-in user's
   own connections (Power Platform for Admins, Microsoft Dataverse,
   Power Platform for Admins V2, Office 365 Outlook). Operation and
   parameter names are discovered at runtime from the pac-generated
   dataSourcesInfo, so connector schema drift can't break the app.
------------------------------------------------------------------------ */
import { getClient } from "@microsoft/power-apps/data";
import { dataSourcesInfo } from "./dsInfo";

const DS: any = dataSourcesInfo || {};
const client: any = getClient(DS);

/** Find the data-source key that exposes a given operation (or regex). */
function findSource(op: string | RegExp): { table: string; op: string } | null {
  for (const table of Object.keys(DS)) {
    const apis = DS[table]?.apis ?? {};
    for (const name of Object.keys(apis)) {
      if (typeof op === "string" ? name === op : op.test(name)) return { table, op: name };
    }
  }
  return null;
}

export const has = (op: string | RegExp) => !!findSource(op);

/** Names of the parameters an operation declares (for body-param discovery). */
function paramsOf(table: string, op: string): any[] {
  return DS[table]?.apis?.[op]?.parameters ?? [];
}

export async function call<T = any>(op: string | RegExp, params: Record<string, any> = {}, bodyValue?: any): Promise<T> {
  const src = findSource(op);
  if (!src) throw new Error(`Connector operation ${String(op)} not added to this app (rerun deploy.ps1)`);
  const p: Record<string, any> = { ...params };
  if (bodyValue !== undefined) {
    const body = paramsOf(src.table, src.op).find((x: any) => x.in === "body");
    p[body?.name ?? "body"] = bodyValue;
  }
  const res = await client.executeAsync({
    connectorOperation: { tableName: src.table, operationName: src.op, parameters: p }
  });
  if (!res?.success) {
    const msg = res?.error?.message ?? JSON.stringify(res?.error ?? res);
    throw new Error(`${src.op}: ${msg}`);
  }
  return res.data as T;
}

/* ---------------- Power Platform for Admins: environments ---------------- */
export type Env = { id: string; name: string; region: string; sku: string; url: string | null; isDefault: boolean };

export async function listEnvironments(): Promise<Env[]> {
  const out: Env[] = [];
  let skip: string | undefined;
  for (let page = 0; page < 20; page++) {
    const data: any = await call("Get-AdminEnvironment", {
      "api-version": "2020-10-01", ...(skip ? { $skiptoken: skip } : {})
    });
    (data?.value ?? []).forEach((e: any) => {
      const p = e.properties ?? {};
      const url = (p.linkedEnvironmentMetadata?.instanceUrl ?? "").replace(/\/?$/, "/");
      out.push({
        id: e.name, name: p.displayName ?? e.name, region: e.location ?? "",
        sku: p.environmentSku ?? "", url: p.linkedEnvironmentMetadata?.instanceUrl ? url : null,
        isDefault: !!p.isDefault
      });
    });
    const next: string = data?.nextLink ?? "";
    const m = next.match(/[?&]\$skiptoken=([^&]+)/i);
    if (!m) break;
    skip = decodeURIComponent(m[1]);
  }
  return out;
}

/* ---------------- Microsoft Dataverse: any environment ------------------- */
export async function listRows(orgUrl: string, entity: string, q: { select?: string; filter?: string; orderby?: string } = {}, max = 20000): Promise<any[]> {
  const top = Math.min(5000, max);
  const rows: any[] = [];
  let skip: string | undefined;
  while (rows.length < max) {
    const data: any = await call("ListRecordsWithOrganization", {
      organization: orgUrl,
      entityName: entity,
      ...(q.select ? { $select: q.select } : {}),
      ...(q.filter ? { $filter: q.filter } : {}),
      ...(q.orderby ? { $orderby: q.orderby } : {}),
      $top: top,
      ...(skip ? { $skiptoken: skip } : {})
    });
    (data?.value ?? []).forEach((r: any) => rows.push(r));
    const next: string = data?.["@odata.nextLink"] ?? "";
    const m = next.match(/[?&]\$skiptoken=([^&]+)/i);
    if (!m) break;
    skip = decodeURIComponent(m[1]);
  }
  return rows;
}

/* ---------------- Power Platform for Admins V2 (optional) ---------------- */
const INVENTORY_OP = /query.*resource|resources.*query|QueryPowerPlatformResources/i;
export const hasInventory = () => has(INVENTORY_OP);

export async function queryInventory(): Promise<any[]> {
  const data: any = await call(INVENTORY_OP, { "api-version": "2024-10-01" },
    { TableName: "PowerPlatformResources", Clauses: [{ $type: "take", TakeCount: 1000 }] });
  return data?.data ?? data?.value ?? [];
}

const Q_GET = /^Get.*Quarantine/i, Q_SET = /^Set.*As.*Quarantined$/i, Q_UNSET = /^Set.*Unquarantined$/i;
export const hasQuarantine = () => has(Q_SET) && has(Q_UNSET);
const qParams = (envId: string, botId: string) => ({ EnvironmentId: envId, BotId: botId, "api-version": "2022-03-01-preview" });
export async function getQuarantine(envId: string, botId: string): Promise<boolean | null> {
  if (!has(Q_GET)) return null;
  const d: any = await call(Q_GET, qParams(envId, botId));
  return !!(d?.isBotQuarantined ?? d?.isQuarantined ?? d?.quarantined);
}
export async function setQuarantine(envId: string, botId: string, on: boolean) {
  return call(on ? Q_SET : Q_UNSET, qParams(envId, botId));
}

/* ---------------- Office 365 Outlook (optional) -------------------------- */
export const hasMail = () => has(/^SendEmailV2$/);
export type Attachment = { name: string; b64: string };
export async function sendMail(to: string, subject: string, html: string, files: Attachment[]) {
  return call(/^SendEmailV2$/, {}, {
    To: to.split(/[,;]/).map(x => x.trim()).filter(Boolean).join(";"),
    Subject: subject, Body: html, Importance: "Normal",
    Attachments: files.map(f => ({ Name: f.name, ContentBytes: f.b64 }))
  });
}

/* ---------------- Office 365 Users: people picker ------------------------- */
export type Person = { name: string; email: string; title?: string };
const PEOPLE_OP = /^SearchUserV2$|^SearchUser$/;
export const hasPeople = () => has(PEOPLE_OP);
export async function searchPeople(term: string, top = 8): Promise<Person[]> {
  const d: any = await call(PEOPLE_OP, { searchTerm: term, top, isSearchTermRequired: true });
  const list: any[] = d?.value ?? (Array.isArray(d) ? d : []);
  return list.map(u => ({ name: u.DisplayName ?? u.displayName ?? "", email: u.Mail ?? u.mail ?? u.UserPrincipalName ?? u.userPrincipalName ?? "", title: u.JobTitle ?? u.jobTitle ?? "" }))
    .filter(p => p.email);
}
/** Fallback people search through Dataverse systemusers (no extra connector). */
export async function searchPeopleDv(orgUrl: string, term: string, top = 8): Promise<Person[]> {
  const t = term.replace(/'/g, "''");
  const rows = await listRows(orgUrl, "systemusers", {
    select: "fullname,internalemailaddress,domainname,title",
    filter: `isdisabled eq false and (startswith(fullname,'${t}') or startswith(firstname,'${t}') or startswith(lastname,'${t}') or startswith(internalemailaddress,'${t}') or startswith(domainname,'${t}'))`
  }, top);
  return rows.map(u => ({ name: u.fullname ?? "", email: u.internalemailaddress || u.domainname || "", title: u.title ?? "" })).filter(p => p.email);
}
