/* 🧬 Agent capability graph — connectors, flows, MCP, skills, knowledge and
   sub-agents drawn as a radial constellation around the agent. */
import { useState } from "react";
import type { Agent } from "./scanner";
import { CAP_STYLE, CapKind } from "./capabilities";

type Node = { label: string; group: string; color: string; icon: string; sub: string; weight: number };
const EXTRA: Record<string, [string, string]> = {
  "Knowledge": ["#3ddc84", "📚"], "Child agent": ["#c99bff", "🧒"], "Connected agent": ["#ff8fb1", "🔗"], "Trigger": ["#ffb454", "⚡"]
};

export default function CapabilityGraph({ a }: { a: Agent }) {
  const [hover, setHover] = useState<Node | null>(null);
  const d = a.details;
  if (!d) return null;
  const nodes: Node[] = [];
  (d.caps ?? []).forEach(c => {
    const [color, icon] = CAP_STYLE[c.kind as CapKind];
    nodes.push({ label: c.name, group: c.kind, color, icon, weight: c.uses,
      sub: `${c.kind}${c.ops.length ? ` • ${c.ops.slice(0, 4).join(", ")}${c.ops.length > 4 ? "…" : ""}` : ""}${c.detail && c.detail !== c.name ? ` • ${c.detail}` : ""}${c.uses > 1 ? ` • used ${c.uses}×` : ""}` });
  });
  (d.skills ?? []).forEach(s => nodes.push({ label: s, group: "Skill", color: CAP_STYLE.Skill[0], icon: CAP_STYLE.Skill[1], sub: "Skill component", weight: 1 }));
  const kn = d.knowledgeNames ?? [];
  kn.slice(0, 5).forEach(k => nodes.push({ label: k, group: "Knowledge", color: EXTRA.Knowledge[0], icon: EXTRA.Knowledge[1], sub: "Knowledge source", weight: 1 }));
  if (kn.length > 5) nodes.push({ label: `+${kn.length - 5} more`, group: "Knowledge", color: EXTRA.Knowledge[0], icon: EXTRA.Knowledge[1], sub: kn.slice(5).join(", "), weight: 1 });
  d.children.forEach(c => nodes.push({ label: c, group: "Child agent", color: EXTRA["Child agent"][0], icon: EXTRA["Child agent"][1], sub: "Child agent (inside this agent)", weight: 1 }));
  d.connected.forEach(c => nodes.push({ label: c, group: "Connected agent", color: EXTRA["Connected agent"][0], icon: EXTRA["Connected agent"][1], sub: "Connected agent (separate bot)", weight: 1 }));
  if (d.triggers) nodes.push({ label: `${d.triggers} trigger${d.triggers > 1 ? "s" : ""}`, group: "Trigger", color: EXTRA.Trigger[0], icon: EXTRA.Trigger[1], sub: "Autonomous / event triggers", weight: d.triggers });

  const MAX = 18;
  const shown = nodes.length > MAX ? [...nodes.slice(0, MAX - 1), { label: `+${nodes.length - MAX + 1} more`, group: "More", color: "#8ca3c7", icon: "…", sub: nodes.slice(MAX - 1).map(n => n.label).join(", "), weight: 1 }] : nodes;
  const groups = new Map<string, number>();
  nodes.forEach(n => groups.set(n.group, (groups.get(n.group) ?? 0) + 1));
  const connectors = (d.caps ?? []).filter(c => c.kind === "Connector" || c.kind === "MCP");
  const maxUse = Math.max(1, ...connectors.map(c => Math.max(c.uses, c.ops.length)));

  const W = 480, H = 340, cx = W / 2, cy = H / 2, R = shown.length <= 6 ? 100 : 118;
  if (!nodes.length) return (
    <div className="capwrap"><div className="sub">No connectors, flows, skills, knowledge or sub-agents detected for this agent
      {a.kind === "Agent Builder" ? " (Agent Builder tools live in Microsoft 365, not Dataverse)." : "."}</div></div>);

  return (
    <div className="capwrap">
      <div className="capchips">{[...groups.entries()].map(([g, n]) => {
        const st = (CAP_STYLE as any)[g] ?? EXTRA[g] ?? ["#8ca3c7", "•"];
        return <span key={g} className="capchip" style={{ borderColor: st[0] }}><span>{st[1]}</span><b>{n}</b> {g}</span>;
      })}</div>
      <div style={{ position: "relative" }}>
        <svg viewBox={`0 0 ${W} ${H}`} width="100%" className="capsvg">
          <defs>
            <radialGradient id="capcore"><stop offset="0%" stopColor="#F27A21" /><stop offset="100%" stopColor="#0B2B4C" /></radialGradient>
          </defs>
          <circle cx={cx} cy={cy} r={R} fill="none" stroke="var(--line)" strokeDasharray="3 5" />
          {shown.map((n, i) => {
            const ang = (i / shown.length) * Math.PI * 2 - Math.PI / 2;
            const x = cx + Math.cos(ang) * R, y = cy + Math.sin(ang) * R;
            const r = 13 + Math.min(7, n.weight * 1.5);
            const right = Math.cos(ang) >= 0;
            const lx = cx + Math.cos(ang) * (R + r + 8), ly = cy + Math.sin(ang) * (R + r + 10) + 4;
            return <g key={i} className="capnode" onMouseEnter={() => setHover(n)} onMouseLeave={() => setHover(null)}>
              <line x1={cx} y1={cy} x2={x} y2={y} stroke={n.color} strokeOpacity=".45" strokeWidth={1 + Math.min(3, n.weight * .6)} className="capflow" />
              <circle cx={x} cy={y} r={r} fill={n.color} fillOpacity=".18" stroke={n.color} strokeWidth="2" />
              <text x={x} y={y + 5} textAnchor="middle" fontSize="13">{n.icon}</text>
              <text x={lx} y={ly} textAnchor={Math.abs(Math.cos(ang)) < .2 ? "middle" : right ? "start" : "end"} className="caplabel">{n.label.length > 22 ? n.label.slice(0, 21) + "…" : n.label}</text>
            </g>;
          })}
          <circle cx={cx} cy={cy} r="30" fill="url(#capcore)" className="capcore" />
          <text x={cx} y={cy + 5} textAnchor="middle" fontSize="18">🤖</text>
        </svg>
        {hover && <div className="captip"><b>{hover.icon} {hover.label}</b><div className="sub">{hover.sub}</div></div>}
      </div>
      {connectors.length > 0 && <>
        <div className="capsub">🔌 Connectors & MCP servers in use</div>
        {connectors.map((c, i) => (
          <div key={i} className="capbar">
            <span className="capbarname" title={c.detail}>{CAP_STYLE[c.kind][1]} {c.name}</span>
            <div className="capbartrack"><div className="capbarfill" style={{ width: `${(Math.max(c.uses, c.ops.length) / maxUse) * 100}%`, background: CAP_STYLE[c.kind][0] }} /></div>
            <span className="capbarops">{c.ops.length ? c.ops.slice(0, 3).join(", ") + (c.ops.length > 3 ? ` +${c.ops.length - 3}` : "") : `${c.uses}×`}</span>
          </div>))}
      </>}
    </div>
  );
}
