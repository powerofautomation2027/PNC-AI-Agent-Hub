/* ------------------------------------------------------------------------
   Community features
   🔌 Connector Atlas — DLP-style tiers (Microsoft Learn "Establish a DLP
      strategy", "Connector classification", endpoint-filtering targets) +
      the documented UNBLOCKABLE connector list.
   👯 Agent Sprawl — twin/sibling detection (Agent 365 registry concept;
      no published algorithm → name normalisation + shingle Jaccard +
      connector-set Jaccard, union-find clusters).
------------------------------------------------------------------------ */
import type { Agent } from "./scanner";

export type Tier = "High" | "Medium" | "Low" | "Custom";
const HIGH = /^shared_(webcontents|smtp|ftp|sftp\w*|sendmail|dropbox|googledrive|gmail|twitter|slack|bingsearch|box|facebook|instagram|telegram\w*|rss|httpwebhook|webhook|onedrive)$/;
const MEDIUM = /^shared_(sql|azureblob|azureopenai|azuretables|keyvault|azurefile|cognitiveservices\w*|openai\w*|servicebus|azurequeues|documentdb|kusto|mysql|postgresql|oracle|salesforce|servicenow|jira|github|flowmanagement|powerplatformforadmins\w*)$/;
const LOW = /^shared_(office365|office365users|office365groups\w*|sharepointonline|onedriveforbusiness|teams|commondataserviceforapps|excelonlinebusiness|planner|powerbi|approvals|onenote|todo|microsoftforms|shifts|yammer|kaizala|conversionservice|outlooktasks|wordonlinebusiness)$/;
const UNBLOCKABLE = /^shared_(office365|office365users|teams|sharepointonline|onedriveforbusiness|excelonlinebusiness|onenote|planner|powerbi|todo|office365groups|shifts|yammer|kaizala|cloudappsecurity|customervoice|approvals|flowpush|commondataserviceforapps|powerappsnotification\w*|microsoftcopilotstudio)$/;
export function tierOf(api: string, kind: string): Tier {
  const a = api.toLowerCase();
  if (kind === "HTTP") return "High";
  if (kind === "MCP") return /microsoftlearn|microsoft/.test(a) ? "Medium" : "High";
  if (HIGH.test(a)) return "High";
  if (MEDIUM.test(a)) return "Medium";
  if (LOW.test(a)) return "Low";
  return /-5f|^shared_[a-z0-9]+-/.test(a) || !/^shared_/.test(a) ? "Custom" : "Medium";
}
export const isUnblockable = (api: string) => UNBLOCKABLE.test(api.toLowerCase());

export type AtlasRow = { key: string; name: string; kind: string; tier: Tier; unblockable: boolean; agents: Agent[]; ops: string[]; envs: string[] };
export function atlas(agents: Agent[]): AtlasRow[] {
  const m = new Map<string, AtlasRow>();
  agents.forEach(a => (a.details?.caps ?? []).forEach(c => {
    if (!["Connector", "MCP", "HTTP", "Computer use", "Plugin / REST"].includes(c.kind)) return;
    const api = c.kind === "Connector" || c.kind === "MCP" ? c.api : c.name;
    const key = `${c.kind}|${c.name}`;
    const r = m.get(key) ?? { key, name: c.name, kind: c.kind, tier: tierOf(api, c.kind), unblockable: c.kind === "Connector" && isUnblockable(api), agents: [], ops: [], envs: [] };
    if (!r.agents.includes(a)) r.agents.push(a);
    c.ops.forEach(o => !r.ops.includes(o) && r.ops.push(o));
    if (!r.envs.includes(a.envName)) r.envs.push(a.envName);
    m.set(key, r);
  }));
  const order: Record<Tier, number> = { High: 0, Custom: 1, Medium: 2, Low: 3 };
  return [...m.values()].sort((x, y) => order[x.tier] - order[y.tier] || y.agents.length - x.agents.length);
}
/* ------------------------------- sprawl ------------------------------- */
const STOP = new Set("a an the and or of to in for on with you your is are be as at by this that it from will can should must when if not do does any all our we i me my".split(" "));
export const normName = (n: string) => n.toLowerCase()
  .replace(/\b(copy of|copy|v\d+(\.\d+)*|\(\d+\)|test|dev|prod|uat|draft|new|old|final)\b/g, " ")
  .replace(/[^a-z0-9]+/g, " ").trim();
const trigrams = (s: string) => { const t = ` ${s} `; const o = new Set<string>(); for (let i = 0; i < t.length - 2; i++) o.add(t.slice(i, i + 3)); return o; };
const shingles = (s: string) => {
  const w = s.toLowerCase().replace(/[^a-z0-9 ]+/g, " ").split(/\s+/).filter(x => x && !STOP.has(x));
  const o = new Set<string>(); for (let i = 0; i + 2 < w.length; i++) o.add(w[i] + " " + w[i + 1] + " " + w[i + 2]); return o;
};
const jac = (a: Set<string>, b: Set<string>) => {
  if (!a.size || !b.size) return 0;
  const [s, l] = a.size < b.size ? [a, b] : [b, a]; let n = 0; s.forEach(x => l.has(x) && n++);
  return n / (a.size + b.size - n);
};
export type Pair = { a: Agent; b: Agent; score: number; name: number; instr: number; conn: number; why: string[] };
export type Cluster = { members: Agent[]; pairs: Pair[]; top: number; label: "Twin" | "Sibling" };

export function sprawl(list: Agent[]): Cluster[] {
  const ag = list.filter(a => a.kind !== "Flow" && !a.relation).slice(0, 3000);
  const F = ag.map(a => ({ a, n: normName(a.name), tri: trigrams(normName(a.name)), sh: shingles(a.details?.instructions ?? ""),
    cn: new Set((a.details?.caps ?? []).map(c => c.kind + c.name)) }));
  // candidate pairs via inverted index (skip very common tokens)
  const idx = new Map<string, number[]>();
  F.forEach((f, i) => [...f.tri, ...[...f.sh].slice(0, 300)].forEach(t => { const l = idx.get(t) ?? []; l.push(i); idx.set(t, l); }));
  const cand = new Set<string>();
  idx.forEach(l => { if (l.length > 60) return; for (let x = 0; x < l.length; x++) for (let y = x + 1; y < l.length; y++) cand.add(l[x] + ":" + l[y]); });
  const pairs: Pair[] = [];
  cand.forEach(k => {
    const [i, j] = k.split(":").map(Number); const A = F[i], B = F[j];
    const name = A.n && A.n === B.n ? 1 : jac(A.tri, B.tri);
    const instr = jac(A.sh, B.sh);
    const conn = A.cn.size && B.cn.size ? jac(A.cn, B.cn) : 0;
    const hasInstr = A.sh.size > 3 && B.sh.size > 3;
    const score = hasInstr ? 0.5 * instr + 0.3 * name + 0.2 * conn : 0.75 * name + 0.25 * conn;
    const why: string[] = [];
    if (A.n && A.n === B.n) why.push("same name (normalised)"); else if (name >= 0.7) why.push(`name ${Math.round(name * 100)}% alike`);
    if (instr >= 0.35) why.push(`instructions ${Math.round(instr * 100)}% alike`);
    if (conn >= 0.8) why.push(`same tools/connectors`);
    if ((score >= 0.5 || (A.n && A.n === B.n)) && why.length) pairs.push({ a: A.a, b: B.a, score: Math.max(score, A.n === B.n ? 0.6 : 0), name, instr, conn, why });
  });
  // union-find
  const parent = new Map<Agent, Agent>(); const find = (x: Agent): Agent => { const p = parent.get(x) ?? x; if (p === x) return x; const r = find(p); parent.set(x, r); return r; };
  pairs.forEach(p => { const ra = find(p.a), rb = find(p.b); if (ra !== rb) parent.set(ra, rb); });
  const groups = new Map<Agent, Cluster>();
  pairs.forEach(p => {
    const r = find(p.a); const c = groups.get(r) ?? { members: [], pairs: [], top: 0, label: "Sibling" as const };
    [p.a, p.b].forEach(m => !c.members.includes(m) && c.members.push(m));
    c.pairs.push(p); c.top = Math.max(c.top, p.score);
    if (p.instr >= 0.6 || (p.name === 1 && (p.instr >= 0.35 || p.conn >= 0.8 || !p.a.details?.instructions))) c.label = "Twin";
    groups.set(r, c);
  });
  return [...groups.values()].sort((x, y) => (x.label === y.label ? 0 : x.label === "Twin" ? -1 : 1) || y.members.length - x.members.length || y.top - x.top);
}
