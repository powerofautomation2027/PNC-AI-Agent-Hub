# Agent Inventory Hub v51 — one Code App, no app registration

Tenant-wide inventory of every Microsoft agent type, running entirely through the
signed-in Power Platform admin's own connections.

## Deploy
    Set-ExecutionPolicy Bypass -Scope Process -Force; & ".\deploy.ps1" "<environment-guid>"
Needs pac CLI, node, npm. No Azure CLI, no Entra app registration, no consent grants.
If a connection is missing, the script opens the Connections page, waits, and continues.

## Connectors
| Connector | Why | Required |
|---|---|---|
| Power Platform for Admins | list every environment in the tenant | yes |
| Microsoft Dataverse (List rows from selected environment) | bots + botcomponents in every environment | yes (premium) |
| Power Platform for Admins V2 | inventory API (authoritative Agent Builder) + quarantine | optional |
| Office 365 Outlook | email report | optional |

## Detection (tenant-verified)
- Copilot Studio = bot with a Custom GPT (15) component
- Agent Builder = inventory `createdIn` lite/M365, or `template` starts with `gpt`
- Classic V1 = bot with no Custom GPT component
- Child agent = Topic V2 (9) component under the parent with `kind: AgentDialog`
- Connected agent = parent topic invoking another bot's schema name
- Autonomous = External Trigger (17) component

## New in v51
- Agent detail drawer: instructions (system prompt), tools, knowledge, children, triggers
- One-click quarantine / release (Power Platform for Admins V2)
- All earlier features kept: tabs, search, env filter, sort, pins, delta, insights,
  OWASP-aligned security review, CSV/PDF on every screen, email, schedule, deep links
