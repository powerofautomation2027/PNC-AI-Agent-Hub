Drop logo PNGs here BEFORE running deploy.ps1 (copied into the app automatically):
  pnc_logo.png    -> PNC logo, shown in the header next to the app name (~38px tall)
  logo_left.png   -> optional extra logo
  logo_right.png  -> optional extra logo
Use only logo files you are authorized to use. Missing files are hidden automatically.
