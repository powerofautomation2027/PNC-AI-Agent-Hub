import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// CRITICAL: relative base + FLAT dot-hash filenames.
// - no /assets/ subfolder (Power Platform 404s on it)
// - hashes for cache busting (fixed names made the player serve stale code)
// - dots not dashes as separator (Dataverse web resource names reject '-';
//   deploy.ps1 additionally sanitizes hyphens inside hashes)
export default defineConfig({
  plugins: [react()],
  base: "./",
  server: { port: 3000, host: "::" },
  build: {
    outDir: "dist",
    assetsDir: ".",
    rollupOptions: {
      output: {
        entryFileNames: "[name].[hash].js",
        chunkFileNames: "[name].[hash].js",
        assetFileNames: "[name].[hash].[ext]"
      }
    }
  }
});
