﻿param(
    [Parameter(Position = 0)]
    [string]$EnvironmentId
)
# ================================================================
# Agent Inventory Hub v51 — ONE Code App, NO app registration
# Every API call runs through the signed-in admin's own Power Platform
# connections (connectors), so: no Entra app, no consent grants, no
# MSAL, no redirect URIs, no CSP allow-list, no Azure resources.
#
# Connectors used:
#   REQUIRED  shared_powerplatformforadmins   list all environments (tenant)
#   REQUIRED  shared_commondataserviceforapps bots + botcomponents in EVERY env
#   OPTIONAL  shared_powerplatformadminv2     inventory (Agent Builder truth) + quarantine
#   REQUIRED  shared_office365                📧 email reports
#   REQUIRED  shared_office365users           👤 people search (email To + owner lookup)
#
# Run:  Set-ExecutionPolicy Bypass -Scope Process -Force; & ".\deploy.ps1" "<envGuid>"
# ================================================================
$ErrorActionPreference = "Stop"
$AppName = "PNC AI Agent Hub"
$Connectors = @(
    @{ Api = "shared_powerplatformforadmins";   Name = "Power Platform for Admins";    Required = $true  },
    @{ Api = "shared_commondataserviceforapps"; Name = "Microsoft Dataverse";          Required = $true  },
    @{ Api = "shared_powerplatformadminv2";     Name = "Power Platform for Admins V2"; Required = $true  },
    @{ Api = "shared_office365";                Name = "Office 365 Outlook";           Required = $true  },
    @{ Api = "shared_office365users";           Name = "Office 365 Users";             Required = $true  }
)

function Step($n, $t) { Write-Host "`n== $n. $t ==" -ForegroundColor Cyan }
function Ok($t)   { Write-Host $t -ForegroundColor Green }
function Warn($t) { Write-Host "WARN: $t" -ForegroundColor Yellow }
function Pac([string]$argLine, [switch]$Quiet) {
    # cmd /c keeps pac attached (PS7 + Out-Null detaches it); capture text for self-heal checks
    $out = cmd.exe /c "pac $argLine 2>&1" | Out-String
    if (-not $Quiet) { Write-Host $out -ForegroundColor DarkGray }
    return $out
}
$StaleSig = "ExternalTokenManagement|No token cache item|Failed to connect to Dataverse|non-recoverable"

# ---------- 0. environment id: parameter > remembered > prompt ----------
$EnvMemoFile = ".\.deploy-env.txt"
$EnvInput = $EnvironmentId
if ([string]::IsNullOrWhiteSpace($EnvInput) -and (Test-Path $EnvMemoFile)) {
    $remembered = (Get-Content $EnvMemoFile -Raw).Trim()
    if ($remembered) {
        $ans = Read-Host "Environment [$remembered] - press ENTER to reuse, or type a different ID"
        $EnvInput = if ([string]::IsNullOrWhiteSpace($ans)) { $remembered } else { $ans }
    }
}
if ([string]::IsNullOrWhiteSpace($EnvInput)) { $EnvInput = Read-Host "Power Platform Environment ID (GUID) to host the app" }
if ([string]::IsNullOrWhiteSpace($EnvInput)) { throw "Environment ID is required." }
$EnvInput = $EnvInput.Trim()
Set-Content -Path $EnvMemoFile -Value $EnvInput -Encoding UTF8

# ---------- 1. prerequisites ----------
Step 1 "Prerequisites (pac, node, npm)"
foreach ($cmd in @("pac", "node", "npm")) {
    if (-not (Get-Command $cmd -ErrorAction SilentlyContinue)) { throw "'$cmd' not found in PATH." }
}
Ok "pac / node / npm found (Azure CLI NOT needed in v51)"

# ---------- 2. pac auth + environment (self-healing) ----------
Step 2 "Power Platform sign-in + environment"
function Repair-PacAuth {
    Warn "pac token cache stale - rebuilding auth (one browser sign-in)"
    Pac "auth clear" | Out-Null
    Pac "auth create --environment $EnvInput" | Out-Null
}
$who = Pac "auth who"
if ($who -match "No profiles|$StaleSig") { Repair-PacAuth }
$sel = Pac "env select --environment $EnvInput"
if ($sel -match $StaleSig) { Repair-PacAuth; $sel = Pac "env select --environment $EnvInput" }
$envWho = Pac "env who"
if ($envWho -match $StaleSig) { Repair-PacAuth; $envWho = Pac "env who" }
if ($envWho -notmatch "Environment ID") { throw "Could not select environment $EnvInput" }
Ok "Environment selected: $EnvInput"

# ---------- 3. connections (the ONLY auth the app needs) ----------
Step 3 "Power Platform connections"
function Get-ConnId([string]$api) {
    $list = Pac "connection list" -Quiet
    if ($list -match $StaleSig) { Repair-PacAuth; $list = Pac "connection list" -Quiet }
    foreach ($line in ($list -split "`r?`n")) {
        if ($line -match ([regex]::Escape($api) + "(?![a-z0-9])") -and $line -notmatch "Error|Unauthenticated") {
            $m = [regex]::Match($line, "\b([0-9a-f]{32}|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\b")
            if ($m.Success) { return $m.Groups[1].Value }
        }
    }
    return $null
}
$ConnIds = @{}
$missing = @()
foreach ($c in $Connectors) {
    $id = Get-ConnId $c.Api
    if ($id) { $ConnIds[$c.Api] = $id; Ok "Connection found: $($c.Name) ($id)" } else { $missing += $c }
}
if ($missing.Count -gt 0) {
    Warn "Missing connection(s): $(($missing | ForEach-Object { $_.Name }) -join ', ')"
    Write-Host "A browser opens on the Connections page. Click '+ New connection', search the EXACT names below, Create, sign in:" -ForegroundColor Yellow
    $missing | ForEach-Object { Write-Host "     -> $($_.Name)" -ForegroundColor Yellow }
    Write-Host "(sign in as the Power Platform admin). The script waits and detects them automatically." -ForegroundColor Yellow
    Start-Process "https://make.powerapps.com/environments/$EnvInput/connections/available"
    $deadline = (Get-Date).AddMinutes(20)
    while ((Get-Date) -lt $deadline) {
        Start-Sleep -Seconds 15
        Write-Host "   waiting for: $(($missing | ForEach-Object { $_.Name }) -join ', ')" -ForegroundColor DarkGray
        foreach ($c in @($missing)) {
            $id = Get-ConnId $c.Api
            if ($id) { $ConnIds[$c.Api] = $id; Ok "Connection detected: $($c.Name) ($id)"; $missing = @($missing | Where-Object { $_.Api -ne $c.Api }) }
        }
        if (@($missing | Where-Object { $_.Required }).Count -eq 0) {
            if ($missing.Count -eq 0) { break }
            $ans = Read-Host "Required connections ready. Press ENTER to continue without optional ($(($missing | ForEach-Object { $_.Name }) -join ', ')), or W to keep waiting"
            if ($ans -ne "W" -and $ans -ne "w") { break }
        }
    }
}
foreach ($c in $Connectors | Where-Object { $_.Required }) {
    if (-not $ConnIds[$c.Api]) { throw "Required connection '$($c.Name)' not found. Create it at make.powerapps.com > Connections and rerun." }
}

# ---------- 4. npm install ----------
Step 4 "npm install"
cmd.exe /c "npm install 2>&1" | Out-Host

# ---------- 5. code app init ----------
Step 5 "Code app init"
if (-not (Test-Path ".\power.config.json")) {
    $init = Pac "code init -n `"$AppName`""
    if (-not (Test-Path ".\power.config.json")) { throw "pac code init failed: $init" }
}
$cfg = Get-Content ".\power.config.json" -Raw | ConvertFrom-Json
if (-not $cfg.region) {   # known fix for "Invalid URI format" on add-data-source
    $cfg | Add-Member -NotePropertyName region -NotePropertyValue "prod" -Force
    $cfg | ConvertTo-Json -Depth 20 | Set-Content ".\power.config.json" -Encoding UTF8
}
# keep the display name in sync (renames an existing app on push)
$cfg = Get-Content ".\power.config.json" -Raw | ConvertFrom-Json
foreach ($k in @("appDisplayName", "displayName")) {
    if ($cfg.PSObject.Properties.Name -contains $k -or $k -eq "appDisplayName") { $cfg | Add-Member -NotePropertyName $k -NotePropertyValue $AppName -Force }
}
$cfg | ConvertTo-Json -Depth 20 | Set-Content ".\power.config.json" -Encoding UTF8
Ok "power.config.json ready (app name: $AppName)"

# ---------- 6. add connector data sources ----------
Step 6 "Connector data sources"
$cfgText = Get-Content ".\power.config.json" -Raw
foreach ($c in $Connectors) {
    $id = $ConnIds[$c.Api]
    if (-not $id) { Warn "Skipping $($c.Name) (no connection) - related feature hidden in the app"; continue }
    if ($cfgText -match ([regex]::Escape($c.Api) + "(?![a-z0-9])")) { Ok "Already added: $($c.Name)"; continue }
    $out = Pac "code add-data-source -a $($c.Api) -c $id"
    if ($out -match $StaleSig) { Repair-PacAuth; $out = Pac "code add-data-source -a $($c.Api) -c $id" }
    if ($out -match "Error:") {
        if ($c.Required) { throw "Adding $($c.Name) failed - see output above" } else { Warn "Optional $($c.Name) not added" }
    } else { Ok "Added: $($c.Name)" }
}

# point src/dsInfo.ts at whatever path pac generated the schema to
$ds = Get-ChildItem -Path "." -Recurse -Filter "dataSourcesInfo.ts" -ErrorAction SilentlyContinue |
      Where-Object { $_.FullName -notmatch "node_modules" } | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $ds) { throw "dataSourcesInfo.ts not generated - add-data-source did not run" }
if ((Get-Content $ds.FullName -Raw) -match "PLACEHOLDER") { throw "dataSourcesInfo.ts is still the placeholder - add-data-source did not run" }
$rel = [IO.Path]::GetRelativePath((Resolve-Path ".\src").Path, $ds.FullName) -replace "\\", "/" -replace "\.ts$", ""
if (-not $rel.StartsWith(".")) { $rel = "./$rel" }
Set-Content ".\src\dsInfo.ts" "// AUTO-GENERATED by deploy.ps1`nexport { dataSourcesInfo } from `"$rel`";" -Encoding UTF8
Ok "Connector schema linked: $rel"

# ---------- 7. build ----------
Step 7 "Build"
$stamp = Get-Date -Format "yyyy-MM-dd HH:mm"
Set-Content -Path ".\src\buildInfo.ts" -Value "export const BUILD_STAMP = `"$stamp`";" -Encoding UTF8
if (Test-Path ".\dist") { Remove-Item ".\dist" -Recurse -Force }
cmd.exe /c "npm run build 2>&1" | Out-Host
if (-not (Test-Path ".\dist\index.html")) { throw "Build failed - no dist/index.html" }
if (Test-Path ".\branding") { Get-ChildItem ".\branding\*.png" -ErrorAction SilentlyContinue | ForEach-Object { Copy-Item $_.FullName ".\dist\$($_.Name)" } }
Ok "Built (stamp $stamp)"

# ---------- 8. push (self-healing) ----------
Step 8 "pac code push"
function Set-AppId([string]$id) {
    $c = Get-Content ".\power.config.json" -Raw | ConvertFrom-Json
    $c | Add-Member -NotePropertyName appId -NotePropertyValue $id -Force
    $c | ConvertTo-Json -Depth 20 | Set-Content ".\power.config.json" -Encoding UTF8
    Ok "Relinked to existing app $id"
}
$push = Pac "code push"
if ($push -match $StaleSig) { Repair-PacAuth; $push = Pac "code push" }
if ($push -match "Existing App: '([0-9a-fA-F-]{36})'") { Set-AppId $Matches[1]; $push = Pac "code push" }
if ($push -notmatch "pushed successfully|successfully been pushed") { throw "pac code push failed - see output above" }
$AppUrl = ([regex]::Match($push, "https://apps\.powerapps\.com/play/\S+")).Value

Write-Host "`n=================================================" -ForegroundColor Green
Write-Host " DONE - PNC AI Agent Hub (connector mode)"   -ForegroundColor Green
Write-Host " App: $AppUrl"                                     -ForegroundColor Green
Write-Host " No app registration. No Azure. No redirect URIs."  -ForegroundColor Green
Write-Host "=================================================" -ForegroundColor Green
Write-Host "First open: click ALLOW on the connections prompt, then 'Scan tenant'." -ForegroundColor Yellow
Write-Host "Header must show 'build $stamp'." -ForegroundColor Yellow
